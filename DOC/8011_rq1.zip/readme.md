## 现在用的开源词表

- Sentiment：VADER + NLTK Opinion Lexicon + AFINN
- Toxicity：LDNOOBW + Google profanity list + profanity-filter + profanitas/abuse + HurtLex EN
- Politeness：ConvoKit politeness markers + `myeomans/politeness` 源码中的 marker（自动下载）
- Constructiveness：由开源 marker 类别自动派生（Reasoning / Agency / Request 等类别），无手写词条


## 当前结论（ICLR 2018-2023）

- `mean_sentiment` 与 accept 显著正相关（最稳定）OR=1.68，p<1e-50
- `mean_politeness` 与 accept 显著正相关 OR=1.28，p≈3.6e-14
- `mean_toxicity` 不显著 p≈0.35 accept/reject 均值几乎一样
- `mean_constructiveness` 单变量弱显著，多变量不显著  OR=0.87，p≈6.6e-06；但它的组间均值差很小（accept 比 reject 低 0.005）

constructiveness 和 politeness 相关性较高（约 0.46），容易出现抑制效应
constructiveness 的方向在当前特征定义下不稳健，需进一步校准
entiment 的 accept-reject 差在 2018-2023 每年都为正，且幅度稳定（约 +0.10 到 +0.16）
politeness 每年都是小幅正差