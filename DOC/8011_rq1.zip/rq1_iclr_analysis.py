from __future__ import annotations

import re
import json
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Set, Tuple

import matplotlib
import numpy as np
import pandas as pd
import seaborn as sns
import statsmodels.api as sm
from nltk import download as nltk_download
from nltk.corpus import opinion_lexicon
from nltk.sentiment import SentimentIntensityAnalyzer
from scipy import stats

matplotlib.use("Agg")


YEARS = [2018, 2019, 2020, 2021, 2022, 2023]
DATA_DIR = Path("iclr")
OUT_DIR = Path("outputs") / "rq1"
LEXICON_DIR = Path("lexicons_cache")
TOXIC_LEXICON_URL = (
    "https://raw.githubusercontent.com/LDNOOBW/List-of-Dirty-Naughty-Obscene-and-Otherwise-Bad-Words/master/en"
)
TOXIC_EXTRA_URLS = [
    "https://raw.githubusercontent.com/coffee-and-fun/google-profanity-words/main/data/en.txt",
    "https://raw.githubusercontent.com/rominf/profanity-filter/master/profanity_filter/data/en_profane_words.txt",
    "https://raw.githubusercontent.com/profanitas/abuse/master/abuse/dataset_en.csv",
]
HURTLEX_URL = "https://raw.githubusercontent.com/valeriobasile/hurtlex/master/lexica/EN/1.2/hurtlex_EN.tsv"
AFINN_URL = "https://raw.githubusercontent.com/fnielsen/afinn/master/afinn/data/AFINN-111.txt"
CONVOKIT_POLITENESS_BASE = (
    "https://raw.githubusercontent.com/CornellNLP/Cornell-Conversational-Analysis-Toolkit/master/"
    "convokit/politeness_collections/politeness_local/lexicons/"
)
CONVOKIT_POLITENESS_FILES = ["ngram_markers.json", "starter_markers.json", "non_starter_markers.json"]
POLITENESS_R_URL = "https://raw.githubusercontent.com/myeomans/politeness/master/R/politeness.R"

TEXT_TYPES_BY_YEAR: Dict[int, List[str]] = {
    2018: ["review"],
    2019: ["review"],
    2020: ["review"],
    2021: ["review"],
    2022: ["main_review"],
    2023: ["strength_and_weaknesses"],
}

DECISION_TYPE_BY_YEAR = {
    2018: "decision",
    2019: "recommendation",
    2020: "decision",
    2021: "decision",
    2022: "decision",
    2023: "decision",
}

FALLBACK_REVIEW_TYPES = ["review", "main_review", "strength_and_weaknesses", "summary_of_the_review"]

CORE_FEATURES = ["mean_sentiment", "mean_politeness", "mean_toxicity", "mean_constructiveness"]


@dataclass
class LexiconResources:
    sentiment_pos_words: Set[str]
    sentiment_neg_words: Set[str]
    afinn_scores: Dict[str, float]
    politeness_pos_words: Set[str]
    politeness_neg_words: Set[str]
    politeness_pos_phrases: List[str]
    politeness_neg_phrases: List[str]
    hedge_words: Set[str]
    hedge_phrases: List[str]
    toxic_words: Set[str]
    toxic_phrases: List[str]
    constructive_words: Set[str]
    constructive_phrases: List[str]


def ensure_nltk_lexicons() -> None:
    for resource in ["vader_lexicon", "opinion_lexicon"]:
        try:
            nltk_download(resource, quiet=True)
        except Exception:
            pass


def normalize_lexicon_item(item: str) -> str:
    return re.sub(r"\s+", " ", str(item).strip().lower())


def load_nltk_opinion_words() -> Tuple[Set[str], Set[str]]:
    try:
        pos = {normalize_lexicon_item(w) for w in opinion_lexicon.positive()}
        neg = {normalize_lexicon_item(w) for w in opinion_lexicon.negative()}
        return pos, neg
    except Exception:
        return set(), set()


def download_file_if_missing(url: str, dest: Path) -> None:
    if dest.exists():
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        urllib.request.urlretrieve(url, dest)
    except Exception as exc:
        print(f"[WARN] Failed to download {url}: {exc}")


def load_afinn_scores() -> Dict[str, float]:
    afinn_path = LEXICON_DIR / "AFINN-111.txt"
    download_file_if_missing(AFINN_URL, afinn_path)
    scores: Dict[str, float] = {}
    if not afinn_path.exists():
        return scores

    for line in afinn_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        if "\t" not in line:
            continue
        term, val = line.split("\t", 1)
        term = normalize_lexicon_item(term)
        if not term or " " in term:
            continue
        try:
            scores[term] = float(val)
        except ValueError:
            continue
    return scores


def load_convokit_politeness_markers() -> Dict[str, List[str]]:
    markers: Dict[str, List[str]] = {}
    for filename in CONVOKIT_POLITENESS_FILES:
        url = CONVOKIT_POLITENESS_BASE + filename
        local_path = LEXICON_DIR / f"convokit_{filename}"
        download_file_if_missing(url, local_path)
        if not local_path.exists():
            continue
        try:
            data = json.loads(local_path.read_text(encoding="utf-8", errors="ignore"))
        except Exception as exc:
            print(f"[WARN] Failed to parse ConvoKit marker file {filename}: {exc}")
            continue
        if not isinstance(data, dict):
            continue
        for key, values in data.items():
            if not isinstance(values, list):
                continue
            normalized_values = [normalize_lexicon_item(v) for v in values if normalize_lexicon_item(v)]
            markers.setdefault(key, []).extend(normalized_values)
    for key in list(markers.keys()):
        markers[key] = sorted(set(markers[key]))
    return markers


def extract_quoted_strings(text: str) -> List[str]:
    return [m.group(1) for m in re.finditer(r'"([^"\\]*(?:\\.[^"\\]*)*)"', text)]


def load_politeness_r_markers() -> Dict[str, List[str]]:
    local_path = LEXICON_DIR / "politeness_R_source.R"
    download_file_if_missing(POLITENESS_R_URL, local_path)
    if not local_path.exists():
        return {}

    try:
        source = local_path.read_text(encoding="utf-8", errors="ignore")
    except Exception as exc:
        print(f"[WARN] Failed to read politeness R source: {exc}")
        return {}

    # Keep the lightweight marker section before parser-specific blocks.
    source = source.split('if(parser[1]!="spacy"){')[0]
    matches = re.finditer(
        r'features\[\["(?P<name>[^"]+)"\]\]\s*<-\s*(?P<body>.*?)(?=\n\s*features\[\["|\Z)',
        source,
        flags=re.S,
    )
    markers: Dict[str, List[str]] = {}
    for match in matches:
        name = match.group("name")
        body = match.group("body")
        values = []
        for raw in extract_quoted_strings(body):
            val = normalize_lexicon_item(raw)
            val = re.sub(r"[^a-z0-9\s\-']", "", val)
            val = normalize_lexicon_item(val)
            if not val:
                continue
            values.append(val)
        if values:
            markers[name] = sorted(set(values))
    return markers


def merge_marker_maps(*maps: Dict[str, List[str]]) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    for one_map in maps:
        for k, vals in one_map.items():
            out.setdefault(k, []).extend(vals)
    for k in list(out.keys()):
        out[k] = sorted(set(out[k]))
    return out


def split_words_and_phrases(items: Set[str]) -> Tuple[Set[str], Set[str]]:
    words = {x for x in items if " " not in x}
    phrases = {x for x in items if " " in x}
    return words, phrases


def category_union(markers: Dict[str, List[str]], categories: Set[str]) -> Set[str]:
    out: Set[str] = set()
    for cat in categories:
        out |= set(markers.get(cat, []))
    return out


def parse_toxic_source_lines(lines: List[str], is_csv_header: bool = False) -> List[str]:
    out = []
    start_idx = 1 if is_csv_header else 0
    for raw_line in lines[start_idx:]:
        item = normalize_lexicon_item(raw_line)
        if not item or item.startswith("#"):
            continue
        # Simple CSV handling for single-column files.
        if "," in item:
            item = normalize_lexicon_item(item.split(",")[0])
        out.append(item)
    return out


def load_toxic_lexicon() -> Tuple[Set[str], List[str]]:
    toxic_words: Set[str] = set()
    toxic_phrases: List[str] = []

    toxic_sources = [TOXIC_LEXICON_URL] + TOXIC_EXTRA_URLS
    for idx, url in enumerate(toxic_sources):
        source_path = LEXICON_DIR / f"toxic_source_{idx}.txt"
        download_file_if_missing(url, source_path)
        if not source_path.exists():
            continue
        raw_lines = source_path.read_text(encoding="utf-8", errors="ignore").splitlines()
        rows = parse_toxic_source_lines(raw_lines, is_csv_header=url.endswith(".csv"))
        for item in rows:
            item = re.sub(r"[^a-z0-9\s\-']", "", item)
            item = normalize_lexicon_item(item)
            if not item:
                continue
            if " " in item:
                if len(item.replace(" ", "")) < 4:
                    continue
                toxic_phrases.append(item)
            else:
                if len(item) < 3:
                    continue
                toxic_words.add(item)

    # Add HurtLex EN (8k+ entries) for broader abusive/offensive coverage.
    hurtlex_path = LEXICON_DIR / "hurtlex_en.tsv"
    download_file_if_missing(HURTLEX_URL, hurtlex_path)
    if hurtlex_path.exists():
        try:
            hdf = pd.read_csv(hurtlex_path, sep="\t")
            if "lemma" in hdf.columns:
                for lemma in hdf["lemma"].dropna().astype(str):
                    item = normalize_lexicon_item(lemma)
                    item = re.sub(r"[^a-z0-9\s\-']", "", item)
                    item = normalize_lexicon_item(item)
                    if not item:
                        continue
                    if " " in item:
                        if len(item.replace(" ", "")) < 4:
                            continue
                        toxic_phrases.append(item)
                    else:
                        if len(item) < 3:
                            continue
                        toxic_words.add(item)
        except Exception as exc:
            print(f"[WARN] Failed to parse HurtLex: {exc}")

    toxic_phrases = sorted(set(toxic_phrases))
    return toxic_words, toxic_phrases


def build_lexicon_resources() -> LexiconResources:
    ensure_nltk_lexicons()
    senti_pos, senti_neg = load_nltk_opinion_words()
    afinn_scores = load_afinn_scores()
    convokit_markers = load_convokit_politeness_markers()
    politeness_r_markers = load_politeness_r_markers()
    all_markers = merge_marker_maps(convokit_markers, politeness_r_markers)

    # Merge AFINN polarity buckets into sentiment lexicons.
    senti_pos |= {w for w, s in afinn_scores.items() if s > 0}
    senti_neg |= {w for w, s in afinn_scores.items() if s < 0}
    toxic_words, toxic_phrases = load_toxic_lexicon()

    all_categories = set(all_markers.keys())
    negative_categories = {"Swearing"}
    hedge_categories = {"Hedges"}

    politeness_positive_categories = all_categories - negative_categories - hedge_categories
    politeness_negative_categories = negative_categories

    constructive_categories = {
        c
        for c in all_categories
        if re.search(
            r"(reason|contrast|agency|could\.you|can\.you|subjunctive|indicative|please|let\.me\.know|for\.you|for\.me|question)",
            c.lower(),
        )
    }

    politeness_pos_markers = category_union(all_markers, politeness_positive_categories)
    politeness_neg_markers = category_union(all_markers, politeness_negative_categories)
    hedge_markers = category_union(all_markers, hedge_categories)
    constructive_markers = category_union(all_markers, constructive_categories)

    # Clean and split markers to match tokenizer behavior.
    senti_pos = {w for w in senti_pos if " " not in w}
    senti_neg = {w for w in senti_neg if " " not in w}

    politeness_pos_words, politeness_pos_phrases = split_words_and_phrases(politeness_pos_markers)
    politeness_neg_words, politeness_neg_phrases = split_words_and_phrases(politeness_neg_markers)
    hedge_words, hedge_phrases = split_words_and_phrases(hedge_markers)
    constructive_words, constructive_phrases = split_words_and_phrases(constructive_markers)

    toxic_words = {w for w in toxic_words if " " not in w} | politeness_neg_words
    toxic_phrases = sorted(set(toxic_phrases) | politeness_neg_phrases)

    return LexiconResources(
        sentiment_pos_words=senti_pos,
        sentiment_neg_words=senti_neg,
        afinn_scores=afinn_scores,
        politeness_pos_words=politeness_pos_words,
        politeness_neg_words=politeness_neg_words,
        politeness_pos_phrases=sorted(politeness_pos_phrases),
        politeness_neg_phrases=sorted(politeness_neg_phrases),
        hedge_words=hedge_words,
        hedge_phrases=sorted(hedge_phrases),
        toxic_words=toxic_words,
        toxic_phrases=toxic_phrases,
        constructive_words=constructive_words,
        constructive_phrases=sorted(constructive_phrases),
    )


def print_lexicon_summary(lexicons: LexiconResources) -> None:
    print(
        "[INFO] Lexicon sizes | "
        f"sentiment_pos={len(lexicons.sentiment_pos_words)}, "
        f"sentiment_neg={len(lexicons.sentiment_neg_words)}, "
        f"afinn={len(lexicons.afinn_scores)}, "
        f"politeness_pos={len(lexicons.politeness_pos_words)}, "
        f"politeness_neg={len(lexicons.politeness_neg_words)}, "
        f"hedge_words={len(lexicons.hedge_words)}, "
        f"hedge_phrases={len(lexicons.hedge_phrases)}, "
        f"toxic_words={len(lexicons.toxic_words)}, "
        f"toxic_phrases={len(lexicons.toxic_phrases)}, "
        f"constructive_words={len(lexicons.constructive_words)}"
    )


def save_lexicon_summary(lexicons: LexiconResources) -> None:
    summary = pd.DataFrame(
        [
            {"lexicon": "sentiment_pos_words", "size": len(lexicons.sentiment_pos_words)},
            {"lexicon": "sentiment_neg_words", "size": len(lexicons.sentiment_neg_words)},
            {"lexicon": "afinn_scores", "size": len(lexicons.afinn_scores)},
            {"lexicon": "politeness_pos_words", "size": len(lexicons.politeness_pos_words)},
            {"lexicon": "politeness_neg_words", "size": len(lexicons.politeness_neg_words)},
            {"lexicon": "politeness_pos_phrases", "size": len(lexicons.politeness_pos_phrases)},
            {"lexicon": "politeness_neg_phrases", "size": len(lexicons.politeness_neg_phrases)},
            {"lexicon": "toxic_words", "size": len(lexicons.toxic_words)},
            {"lexicon": "toxic_phrases", "size": len(lexicons.toxic_phrases)},
            {"lexicon": "constructive_words", "size": len(lexicons.constructive_words)},
            {"lexicon": "constructive_phrases", "size": len(lexicons.constructive_phrases)},
            {"lexicon": "hedge_words", "size": len(lexicons.hedge_words)},
            {"lexicon": "hedge_phrases", "size": len(lexicons.hedge_phrases)},
        ]
    )
    summary.to_csv(OUT_DIR / "lexicon_summary.csv", index=False)


def get_sentiment_analyzer() -> SentimentIntensityAnalyzer:
    try:
        return SentimentIntensityAnalyzer()
    except LookupError:
        nltk_download("vader_lexicon", quiet=True)
        return SentimentIntensityAnalyzer()


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", str(text)).strip()


def tokenize(text: str) -> List[str]:
    return re.findall(r"[a-zA-Z']+", text.lower())


def count_phrases(text_lower: str, phrases: List[str]) -> int:
    return sum(text_lower.count(p) for p in phrases)


def extract_leading_number(text: str) -> float:
    if pd.isna(text):
        return np.nan
    m = re.match(r"^\s*([0-9]+(?:\.[0-9]+)?)", str(text))
    return float(m.group(1)) if m else np.nan


def parse_decision_binary(text: str) -> float:
    if pd.isna(text):
        return np.nan
    t = str(text).strip().lower()
    if "accept" in t:
        return 1.0
    if "reject" in t:
        return 0.0
    if "submitted" in t:
        return 0.0
    if "invite to workshop track" in t:
        return 0.0
    return np.nan


def score_sentiment(text: str, tokens: List[str], sia: SentimentIntensityAnalyzer, lexicons: LexiconResources) -> Dict[str, float]:
    vader = sia.polarity_scores(text)
    pos_hits = sum(tok in lexicons.sentiment_pos_words for tok in tokens)
    neg_hits = sum(tok in lexicons.sentiment_neg_words for tok in tokens)
    afinn_sum = sum(lexicons.afinn_scores.get(tok, 0.0) for tok in tokens)
    afinn_scaled = np.tanh(afinn_sum / max(len(tokens), 1))

    lex_balance = (pos_hits - neg_hits) / (len(tokens) + 8)
    lex_polarity = float(np.tanh(6.0 * lex_balance + 0.8 * afinn_scaled))

    # Blend robust VADER signal with large lexical sentiment signal.
    compound = 0.75 * vader["compound"] + 0.25 * lex_polarity

    lex_pos_ratio = pos_hits / max(len(tokens), 1)
    lex_neg_ratio = neg_hits / max(len(tokens), 1)
    positive_ratio = 0.7 * vader["pos"] + 0.3 * lex_pos_ratio
    negative_ratio = 0.7 * vader["neg"] + 0.3 * lex_neg_ratio
    return {
        "compound": float(np.clip(compound, -1, 1)),
        "positive": float(np.clip(positive_ratio, 0, 1)),
        "negative": float(np.clip(negative_ratio, 0, 1)),
    }


def score_politeness(text: str, tokens: List[str], lexicons: LexiconResources) -> float:
    t = text.lower()
    pos_word_hits = sum(tok in lexicons.politeness_pos_words for tok in tokens)
    neg_word_hits = sum(tok in lexicons.politeness_neg_words for tok in tokens)
    pos_phrase_hits = count_phrases(t, lexicons.politeness_pos_phrases)
    neg_phrase_hits = count_phrases(t, lexicons.politeness_neg_phrases)
    hedge_hits = sum(tok in lexicons.hedge_words for tok in tokens)
    hedge_phrase_hits = count_phrases(t, lexicons.hedge_phrases)
    raw = (
        1.0 * pos_word_hits
        + 1.8 * pos_phrase_hits
        + 0.7 * hedge_hits
        + 0.9 * hedge_phrase_hits
        - 1.2 * neg_word_hits
        - 1.8 * neg_phrase_hits
    ) / (len(tokens) + 8)
    return float(np.clip(0.5 + 0.5 * np.tanh(8.0 * raw), 0, 1))


def score_toxicity(text: str, tokens: List[str], lexicons: LexiconResources) -> float:
    t = text.lower()
    word_hits = sum(tok in lexicons.toxic_words for tok in tokens)
    phrase_hits = count_phrases(t, lexicons.toxic_phrases)
    word_density = word_hits / max(len(tokens), 1)
    sentence_count = max(len([s for s in re.split(r"[.!?]+", text) if s.strip()]), 1)
    phrase_density = phrase_hits / sentence_count
    raw = 2.5 * word_density + 0.8 * phrase_density
    return float(np.clip(raw, 0, 1))


def score_constructiveness(text: str, tokens: List[str], lexicons: LexiconResources) -> float:
    t = text.lower()
    constructive_hits = sum(tok in lexicons.constructive_words for tok in tokens)
    suggestion_phrase_hits = count_phrases(t, lexicons.constructive_phrases)
    sentences = [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]
    sentence_count = max(len(sentences), 1)
    actionable_sentences = 0
    constructive_signal_tokens = lexicons.constructive_words
    constructive_signal_phrases = lexicons.constructive_phrases
    for s in sentences:
        sl = s.lower()
        has_signal_word = any(tok in constructive_signal_tokens for tok in tokenize(sl))
        has_signal_phrase = any(phrase in sl for phrase in constructive_signal_phrases)
        if has_signal_word or has_signal_phrase:
            actionable_sentences += 1
    sentence_ratio = actionable_sentences / sentence_count
    question_ratio = text.count("?") / sentence_count
    raw = (constructive_hits + 1.4 * suggestion_phrase_hits) / (len(tokens) + 8) + sentence_ratio + 0.25 * question_ratio
    return float(np.clip(raw * 2.2, 0, 1))


def extract_text_features(df: pd.DataFrame, sia: SentimentIntensityAnalyzer, lexicons: LexiconResources) -> pd.DataFrame:
    out = df.copy()
    out["review_text"] = out["Content"].astype(str).map(normalize_text)

    def one_row(text: str) -> pd.Series:
        tokens = tokenize(text)
        sentiment = score_sentiment(text, tokens, sia, lexicons)
        return pd.Series(
            {
                "sentiment_compound": sentiment["compound"],
                "sentiment_positive": sentiment["positive"],
                "sentiment_negative": sentiment["negative"],
                "politeness": score_politeness(text, tokens, lexicons),
                "toxicity": score_toxicity(text, tokens, lexicons),
                "constructiveness": score_constructiveness(text, tokens, lexicons),
                "review_length_words": len(tokens),
            }
        )

    feats = out["review_text"].apply(one_row)
    return pd.concat([out[["Forum", "review_text"]], feats], axis=1)


def extract_decision(df_reviews: pd.DataFrame, year: int) -> pd.DataFrame:
    decision_type = DECISION_TYPE_BY_YEAR.get(year, "decision")
    d = df_reviews[df_reviews["Type"] == decision_type][["Forum", "Content"]].copy()
    if d.empty:
        d = df_reviews[df_reviews["Type"] == "decision"][["Forum", "Content"]].copy()
    d = d.rename(columns={"Content": "final_decision_text"})
    d["decision"] = d["final_decision_text"].map(parse_decision_binary)

    if d["decision"].isna().any():
        venue_rows = df_reviews[df_reviews["Type"] == "venue"][["Forum", "Content"]].rename(columns={"Content": "venue_text"})
        d = d.merge(venue_rows, on="Forum", how="left")
        d["decision"] = d["decision"].where(d["decision"].notna(), d["venue_text"].map(parse_decision_binary))
        d = d.drop(columns=["venue_text"])

    d = d.drop_duplicates(subset=["Forum"], keep="first")
    return d


def extract_scores(df_reviews: pd.DataFrame) -> pd.DataFrame:
    score_rows = df_reviews[df_reviews["Type"].isin(["rating", "recommendation"])][["Forum", "Content"]].copy()
    score_rows["score_numeric"] = score_rows["Content"].map(extract_leading_number)
    score_agg = (
        score_rows.dropna(subset=["score_numeric"])
        .groupby("Forum", as_index=False)
        .agg(
            mean_score=("score_numeric", "mean"),
            score_std=("score_numeric", "std"),
            score_count=("score_numeric", "count"),
        )
    )

    conf_rows = df_reviews[df_reviews["Type"] == "confidence"][["Forum", "Content"]].copy()
    conf_rows["confidence_numeric"] = conf_rows["Content"].map(extract_leading_number)
    conf_agg = (
        conf_rows.dropna(subset=["confidence_numeric"])
        .groupby("Forum", as_index=False)
        .agg(
            mean_confidence=("confidence_numeric", "mean"),
            confidence_std=("confidence_numeric", "std"),
            confidence_count=("confidence_numeric", "count"),
        )
    )

    return score_agg.merge(conf_agg, on="Forum", how="outer")


def extract_review_rows(df_reviews: pd.DataFrame, year: int) -> pd.DataFrame:
    target_types = TEXT_TYPES_BY_YEAR.get(year, FALLBACK_REVIEW_TYPES)
    review_rows = df_reviews[df_reviews["Type"].isin(target_types)][["Forum", "Type", "Content"]].copy()
    if review_rows.empty:
        review_rows = df_reviews[df_reviews["Type"].isin(FALLBACK_REVIEW_TYPES)][["Forum", "Type", "Content"]].copy()
    review_rows = review_rows.dropna(subset=["Content"])
    review_rows["Content"] = review_rows["Content"].astype(str).map(normalize_text)
    review_rows = review_rows[review_rows["Content"].str.len() > 0]
    return review_rows


def build_paper_level_for_year(year: int, sia: SentimentIntensityAnalyzer, lexicons: LexiconResources) -> pd.DataFrame:
    reviews_path = DATA_DIR / f"iclr_{year}_reviews.csv"
    papers_path = DATA_DIR / f"iclr_{year}_papers.csv"

    df_reviews = pd.read_csv(reviews_path)
    df_papers = pd.read_csv(papers_path)

    review_rows = extract_review_rows(df_reviews, year)
    review_features = extract_text_features(review_rows, sia, lexicons)
    review_agg = (
        review_features.groupby("Forum", as_index=False)
        .agg(
            mean_sentiment=("sentiment_compound", "mean"),
            min_sentiment=("sentiment_compound", "min"),
            sentiment_std=("sentiment_compound", "std"),
            mean_positive_ratio=("sentiment_positive", "mean"),
            mean_negative_ratio=("sentiment_negative", "mean"),
            mean_politeness=("politeness", "mean"),
            mean_toxicity=("toxicity", "mean"),
            mean_constructiveness=("constructiveness", "mean"),
            num_reviews=("review_text", "count"),
            mean_review_length=("review_length_words", "mean"),
        )
        .fillna({"sentiment_std": 0.0})
    )

    decision_df = extract_decision(df_reviews, year)
    score_df = extract_scores(df_reviews)

    paper_df = df_papers.rename(columns={"Forum": "Forum", "ID": "paper_id", "Title": "title"}).copy()
    merged = (
        paper_df.merge(review_agg, on="Forum", how="left")
        .merge(decision_df[["Forum", "final_decision_text", "decision"]], on="Forum", how="left")
        .merge(score_df, on="Forum", how="left")
    )
    merged["year"] = year
    return merged


def descriptive_and_tests(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for feat in CORE_FEATURES:
        accepted = df.loc[df["decision"] == 1, feat].dropna()
        rejected = df.loc[df["decision"] == 0, feat].dropna()
        if len(accepted) == 0 or len(rejected) == 0:
            continue

        t_stat, t_p = stats.ttest_ind(accepted, rejected, equal_var=False, nan_policy="omit")
        try:
            u_stat, u_p = stats.mannwhitneyu(accepted, rejected, alternative="two-sided")
        except ValueError:
            u_stat, u_p = np.nan, np.nan

        rows.append(
            {
                "feature": feat,
                "accept_mean": accepted.mean(),
                "reject_mean": rejected.mean(),
                "mean_diff_accept_minus_reject": accepted.mean() - rejected.mean(),
                "t_stat": t_stat,
                "t_pvalue": t_p,
                "mannwhitney_u": u_stat,
                "mannwhitney_pvalue": u_p,
                "accept_n": len(accepted),
                "reject_n": len(rejected),
            }
        )
    return pd.DataFrame(rows)


def fit_univariate_logit(df: pd.DataFrame) -> pd.DataFrame:
    y = df["decision"].astype(int)
    rows = []
    for feat in CORE_FEATURES:
        x = df[[feat]].copy()
        valid = x[feat].notna() & y.notna()
        x = x.loc[valid]
        yy = y.loc[valid]
        std = x[feat].std(ddof=0)
        if std == 0 or np.isnan(std):
            continue
        xz = (x[feat] - x[feat].mean()) / std
        X = sm.add_constant(xz, has_constant="add")
        try:
            model = sm.Logit(yy, X).fit(disp=False, maxiter=200)
        except Exception:
            continue
        coef = model.params[feat]
        pval = model.pvalues[feat]
        ci_low, ci_high = model.conf_int().loc[feat]
        rows.append(
            {
                "feature": feat,
                "coef": coef,
                "pvalue": pval,
                "odds_ratio": np.exp(coef),
                "or_ci_low": np.exp(ci_low),
                "or_ci_high": np.exp(ci_high),
                "n": int(valid.sum()),
                "pseudo_r2": float(model.prsquared),
            }
        )
    return pd.DataFrame(rows)


def fit_multivariable_logit(df: pd.DataFrame) -> pd.DataFrame:
    features = CORE_FEATURES + ["num_reviews", "mean_review_length"]
    work = df[["decision"] + features].copy().dropna()
    y = work["decision"].astype(int)
    X_raw = work[features].copy()

    # Standardize so odds ratio corresponds to +1 SD change per feature.
    X = (X_raw - X_raw.mean()) / X_raw.std(ddof=0)
    valid_cols = [c for c in X.columns if X[c].std(ddof=0) > 0 and not X[c].isna().any()]
    X = X[valid_cols]
    X = sm.add_constant(X, has_constant="add")

    model = sm.Logit(y, X).fit(disp=False, maxiter=300)
    coef_table = model.summary2().tables[1].copy()
    coef_table = coef_table.rename(
        columns={
            "Coef.": "coef",
            "Std.Err.": "std_err",
            "z": "z",
            "P>|z|": "pvalue",
            "[0.025": "ci_low",
            "0.975]": "ci_high",
        }
    )
    coef_table["odds_ratio"] = np.exp(coef_table["coef"])
    coef_table["or_ci_low"] = np.exp(coef_table["ci_low"])
    coef_table["or_ci_high"] = np.exp(coef_table["ci_high"])
    coef_table = coef_table.reset_index().rename(columns={"index": "feature"})
    coef_table["n"] = len(work)
    coef_table["pseudo_r2"] = float(model.prsquared)
    return coef_table


def save_plots(df: pd.DataFrame) -> None:
    sns.set_theme(style="whitegrid")
    for feat in CORE_FEATURES:
        fig = sns.boxplot(
            data=df,
            x="decision_label",
            y=feat,
            hue="decision_label",
            palette=["#d95f02", "#1b9e77"],
            legend=False,
        )
        fig.set_title(f"{feat} by Final Decision")
        fig.set_xlabel("Final Decision")
        fig.set_ylabel(feat)
        plot_path = OUT_DIR / f"{feat}_boxplot.png"
        fig.figure.tight_layout()
        fig.figure.savefig(plot_path, dpi=200)
        fig.figure.clf()


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    LEXICON_DIR.mkdir(parents=True, exist_ok=True)
    sia = get_sentiment_analyzer()
    lexicons = build_lexicon_resources()
    print_lexicon_summary(lexicons)
    save_lexicon_summary(lexicons)

    yearly = []
    for year in YEARS:
        print(f"[INFO] Processing {year} ...")
        yearly.append(build_paper_level_for_year(year, sia, lexicons))

    yearly = [df.dropna(axis=1, how="all") for df in yearly]
    paper_level = pd.concat(yearly, ignore_index=True, sort=False)
    paper_level = paper_level[paper_level["decision"].notna()].copy()
    paper_level["decision"] = paper_level["decision"].astype(int)
    paper_level = paper_level[paper_level["num_reviews"].fillna(0) > 0].copy()
    paper_level["decision_label"] = paper_level["decision"].map({1: "accept", 0: "reject"})

    output_main = OUT_DIR / "paper_level_rq1_dataset.csv"
    paper_level.to_csv(output_main, index=False)

    desc = (
        paper_level.groupby("decision_label")[CORE_FEATURES + ["num_reviews", "mean_review_length"]]
        .agg(["mean", "median", "std", "count"])
        .reset_index()
    )
    desc.columns = [
        "decision_label" if c == "decision_label" else f"{c[0]}_{c[1]}".strip("_")
        for c in desc.columns.to_flat_index()
    ]
    desc.to_csv(OUT_DIR / "descriptive_stats.csv", index=False)

    tests_df = descriptive_and_tests(paper_level)
    tests_df.to_csv(OUT_DIR / "univariate_group_tests.csv", index=False)

    uni_logit = fit_univariate_logit(paper_level)
    uni_logit.to_csv(OUT_DIR / "univariate_logit.csv", index=False)

    multi_logit = fit_multivariable_logit(paper_level)
    multi_logit.to_csv(OUT_DIR / "multivariable_logit.csv", index=False)

    save_plots(paper_level)

    print(f"[DONE] Main dataset: {output_main}")
    print(f"[DONE] Outputs saved in: {OUT_DIR.resolve()}")


if __name__ == "__main__":
    main()
