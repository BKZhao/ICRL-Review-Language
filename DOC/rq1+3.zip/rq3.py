"""
RQ3: Stability and Reproducibility of Review Language Effects on Acceptance

Research Question (from Plan.md):
    "Is the relationship between review language and acceptance stable and reproducible
    across years, research areas/tracks, and different levels of reviewer agreement?"

================================================================================
OVERVIEW
================================================================================

This module investigates whether the associations found in RQ1 (between review
sentiment/tone and acceptance decisions) are:
    - STABLE: similar direction and magnitude across different subsets
    - REPRODUCIBLE: appear again when re-estimated on different years or groups
    - GENERALIZABLE: models trained in one context work in another

The key insight is: if review language appears predictive in one subset of data,
does that pattern still hold in other years, topics, and agreement conditions?

================================================================================
HYPOTHESES (from rq3.md Section 1.2)
================================================================================

H3a - Stability across years:
    The association between review language features and acceptance is broadly
    similar from ICLR 2018 to 2023.

H3b - Stability across research areas/tracks:
    The association between review language and acceptance differs somewhat by
    topic area or track, but main patterns remain directionally consistent.

H3c - Moderation by reviewer agreement:
    The relationship between review language and acceptance is STRONGER when
    reviewer disagreement is HIGH, because language may matter more when scores
    alone are less decisive.

================================================================================
DATA REQUIREMENTS
================================================================================

Input: Paper-level dataset from RQ1 (rq1_iclr_analysis.py)
    - Uses the same ICLR 2018-2023 OpenReview data
    - Paper-level aggregation (acceptance is decided at paper level)

Core language features (computed in rq1_iclr_analysis.py, lines 434-506):
    - mean_sentiment: VADER + lexicon blend sentiment compound score
    - mean_politeness: ConvoKit + R politeness markers score
    - mean_toxicity: profanity lexicons + HurtLex score
    - mean_constructiveness: actionable suggestion markers score

Additional features needed for RQ3:
    - Variance in language measures across reviewers (sentiment_std, etc.)
    - Year (categorical: 2018-2023)
    - Research area/track labels (if available, else topic clusters)
    - Reviewer disagreement measure (score_std, score range, or entropy)

Control variables (paper quality proxies):
    - mean_score: average reviewer rating
    - score_std: standard deviation of scores (also used as disagreement measure)
    - mean_confidence: average reviewer confidence
    - num_reviews: number of reviews per paper

================================================================================
IMPLEMENTATION PLAN
================================================================================

The implementation follows the recommended workflow from rq3.md Section 7:

------------------------------------------------------------------------------
STEP 1: Build the Analysis Dataset
------------------------------------------------------------------------------
Load paper-level data from RQ1 output (paper_level_rq1_dataset.csv).
Ensure all required variables are present:
    - final decision (binary: 1=accept, 0=reject)
    - quality proxies (mean_score, score_std, mean_confidence, num_reviews)
    - language features (mean_sentiment, mean_politeness, mean_toxicity,
      mean_constructiveness)
    - year
    - area/track (harmonize labels if inconsistent across years)
    - disagreement level (derive from score_std: low/medium/high terciles)

Year standardization (rq3.md Section 6.5):
    - Standardize language features WITHIN year to account for shifts in
      review form or style over time
    - This ensures "more positive in 2018" is comparable to "more positive in 2023"

------------------------------------------------------------------------------
STEP 2: Descriptive Analysis (rq3.md Section 4.1)
------------------------------------------------------------------------------
Purpose: Detect dataset shifts, outlier years, changes in review style, imbalance.

Analyses to perform:
    - Acceptance rate by year (line plot)
    - Distribution of sentiment, politeness, toxicity, constructiveness by year
    - Mean language scores for accepted vs rejected papers in each year
    - Language distributions across topic areas (if available)
    - Language distributions across disagreement levels (low/medium/high)

Outputs:
    - Line plots showing trends by year
    - Boxplots of language features by decision, stratified by year
    - Subgroup summary tables with sample sizes and class balance

------------------------------------------------------------------------------
STEP 3: Stratified Logistic Regression (rq3.md Section 4.2)
------------------------------------------------------------------------------
Purpose: Interpretable first view of whether effects are stable across subgroups.

Approach: Run SEPARATE logistic regressions for each subgroup:

    Model: accept ~ quality_proxies + language_features

    a) Year-stratified models:
       Fit one model per year (2018, 2019, ..., 2023)
       Compare: coefficient signs, sizes, confidence intervals, model fit

    b) Area-stratified models (if area labels available):
       Fit one model per research area/track
       Compare same metrics

    c) Disagreement-stratified models:
       Split data into low/medium/high disagreement groups (terciles of score_std)
       Fit one model per disagreement level
       Test H3c: Are language effects stronger in high-disagreement group?

Limitation: Small subgroups may produce noisy estimates.

------------------------------------------------------------------------------
STEP 4: Pooled Logistic Regression with Interactions (rq3.md Section 4.3)
------------------------------------------------------------------------------
Purpose: Main inferential model - directly test whether language effects vary
by context using interaction terms.

Model structure:
    accept ~ quality_proxies + language + year + area + disagreement
             + language*year + language*area + language*disagreement

Interpretation of interaction terms:
    - language*year small/non-significant => temporal stability (supports H3a)
    - language*area significant => language effects differ by field
    - language*disagreement significant => agreement level moderates relationship
      (if positive, supports H3c: language matters more when scores are contested)

Implementation notes:
    - Use standardized (within-year) language features
    - Include all four core language features or select based on RQ1 results
    - Report odds ratios with 95% confidence intervals

------------------------------------------------------------------------------
STEP 5: Multilevel/Hierarchical Logistic Regression (rq3.md Section 4.4)
------------------------------------------------------------------------------
Purpose: Handle nested structure (papers within years/areas) and avoid
over-interpreting small subgroups.

Structure:
    - Papers nested within years and areas
    - Random intercepts for year and area
    - Random slopes for language features by year or area

What this tells us:
    - Average effect of each language feature (fixed effect)
    - How much that effect varies across contexts (random effect variance)
    - Whether variation is due to sampling noise or true heterogeneity

Advantage over stratified models:
    - Partial pooling improves estimates for small subgroups
    - Formal quantification of cross-context heterogeneity

------------------------------------------------------------------------------
STEP 6: Cross-Year and Cross-Group Prediction Tests (rq3.md Section 4.5)
------------------------------------------------------------------------------
Purpose: Test reproducibility through predictive generalization.

Temporal generalization experiments:
    a) Train on 2018-2021, test on 2022
    b) Train on 2018-2022, test on 2023
    c) Leave-one-year-out cross-validation

Cross-area generalization (if areas available):
    Train on some areas, test on others

Evaluation metrics:
    - AUC-ROC
    - Log loss
    - Brier score
    - Calibration plots
    - Delta performance: (model with language) vs (model without language)

Interpretation:
    - If language features improve prediction consistently across held-out years,
      the relationship is reproducible
    - If gains are inconsistent, relationship may be context-specific

------------------------------------------------------------------------------
STEP 7: Meta-Analytic Comparison (rq3.md Section 4.6)
------------------------------------------------------------------------------
Purpose: Formal statistical test of heterogeneity across subgroups.

Procedure:
    1. Estimate coefficient of each language feature in each year separately
    2. Treat each year-specific estimate as a separate "study"
    3. Combine estimates using random-effects meta-analysis
    4. Compute heterogeneity statistics (I^2, Q statistic)

What this answers:
    - Are effects consistent across years? (low I^2 => consistent)
    - Is there substantial heterogeneity? (high I^2, significant Q => heterogeneous)

================================================================================
ROBUSTNESS CHECKS (rq3.md Section 6)
================================================================================

6.1 Alternative language measurements:
    - Compare lexicon-based vs transformer-based sentiment
    - Use different toxicity models
    - Use different constructiveness measures

6.2 Alternative aggregation strategies:
    - Mean vs median language score per paper
    - Max/min review tone (extreme review may matter most)
    - Variance across reviews

6.3 Alternative definitions of disagreement:
    - Standard deviation of scores
    - Score range (max - min)
    - Disagreement categories based on terciles or quartiles

6.4 Consistent review stage:
    - Use only initial official reviews (avoid data leakage from post-rebuttal
      comments that may reflect emerging consensus)

6.5 Year normalization:
    - Standardize variables within year when appropriate

6.6 Multiple testing control:
    - Apply false discovery rate (FDR) correction for multiple comparisons
    - Focus on effect sizes and confidence intervals, not just p-values

================================================================================
OUTPUT FILES
================================================================================

Expected outputs in outputs/rq3/ directory:
    - descriptive_by_year.csv: acceptance rates and language means by year
    - descriptive_by_disagreement.csv: statistics by disagreement level
    - stratified_logit_by_year.csv: year-specific regression coefficients
    - stratified_logit_by_disagreement.csv: disagreement-group coefficients
    - pooled_interaction_model.csv: full interaction model results
    - hierarchical_model_summary.csv: multilevel model fixed and random effects
    - cross_year_validation.csv: temporal generalization metrics
    - meta_analysis_results.csv: heterogeneity statistics
    - Various plots (line plots, forest plots, coefficient comparison plots)

================================================================================
INTERPRETATION SCENARIOS (rq3.md Section 8)
================================================================================

Scenario A - Strong stability:
    Language coefficients have similar signs and sizes across years/areas,
    predictive gains are consistent.
    => "The relationship between review language and acceptance is relatively
        stable and reproducible."

Scenario B - Partial stability:
    Direction is consistent but magnitude changes.
    => "Review language matters, but its strength depends on context."

Scenario C - Instability:
    Effects appear in some years but reverse or disappear in others.
    => "Review language is not a robust predictor across settings; conclusions
        from one year may not generalize."

Scenario D - Strong disagreement moderation:
    Language matters more when score disagreement is high.
    => "Review language may play a larger role in borderline or controversial
        papers, where numerical ratings alone are less decisive."

================================================================================
DEPENDENCIES
================================================================================

Required packages:
    - pandas, numpy: data manipulation
    - statsmodels: logistic regression
    - scipy: statistical tests
    - sklearn: cross-validation, metrics (AUC, log loss, Brier score)
    - matplotlib, seaborn: visualization
    - (optional) pymer4 or statsmodels.MixedLM: hierarchical models
    - (optional) meta-analysis package (e.g., PythonMeta) for formal meta-analysis

Input files:
    - outputs/rq1/paper_level_rq1_dataset.csv (from rq1_iclr_analysis.py)

================================================================================
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib
import numpy as np
import pandas as pd
import seaborn as sns
import statsmodels.api as sm
from scipy import stats
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ------------------------------------------------------------------------------
# Constants
# ------------------------------------------------------------------------------
RQ1_OUTPUT = Path("outputs/rq1/paper_level_rq1_dataset.csv")
OUT_DIR = Path("outputs/rq3")
CORE_LANGUAGE_FEATURES = [
    "mean_sentiment",
    "mean_politeness",
    "mean_toxicity",
    "mean_constructiveness",
]
QUALITY_PROXIES = ["mean_score", "score_std", "mean_confidence", "num_reviews"]
YEARS = [2018, 2019, 2020, 2021, 2022, 2023]


# ==============================================================================
# STEP 1: Data Loading and Preparation
# ==============================================================================


def load_rq1_data() -> pd.DataFrame:
    """
    Load paper-level dataset from RQ1 output.

    Returns DataFrame with columns:
        - decision: binary (1=accept, 0=reject)
        - year: conference year
        - Language features: mean_sentiment, mean_politeness, mean_toxicity,
          mean_constructiveness
        - Quality proxies: mean_score, score_std, mean_confidence, num_reviews
    """
    df = pd.read_csv(RQ1_OUTPUT)
    df = df[df["decision"].notna()].copy()
    df["decision"] = df["decision"].astype(int)
    return df


def add_disagreement_levels(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add disagreement level categories based on score_std terciles.

    Creates 'disagreement_level' column with values: 'low', 'medium', 'high'
    This operationalizes reviewer agreement for H3c testing.

    Papers with score_std in bottom tercile = low disagreement (reviewers agree)
    Papers with score_std in top tercile = high disagreement (reviewers disagree)
    """
    df = df.copy()
    df["score_std"] = df["score_std"].fillna(0)
    terciles = df["score_std"].quantile([0.33, 0.67])
    df["disagreement_level"] = pd.cut(
        df["score_std"],
        bins=[-np.inf, terciles.iloc[0], terciles.iloc[1], np.inf],
        labels=["low", "medium", "high"],
    )
    return df


def standardize_within_year(df: pd.DataFrame, features: List[str]) -> pd.DataFrame:
    """
    Standardize features within each year (z-score normalization).

    This accounts for potential shifts in review style or scoring over time,
    ensuring that "more positive in 2018" is comparable to "more positive in 2023".

    From rq3.md Section 6.5: Year normalization.
    """
    df = df.copy()
    for feat in features:
        if feat not in df.columns:
            continue
        df[f"{feat}_std"] = df.groupby("year")[feat].transform(
            lambda x: (x - x.mean()) / x.std() if x.std() > 0 else 0
        )
    return df


def prepare_analysis_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """
    Prepare the full analysis dataset for RQ3.

    Steps:
        1. Add disagreement levels (terciles of score_std)
        2. Standardize language features within year
        3. Create year dummies for interaction models
    """
    df = add_disagreement_levels(df)
    df = standardize_within_year(df, CORE_LANGUAGE_FEATURES + QUALITY_PROXIES)
    df["year_cat"] = df["year"].astype(str)
    return df


# ==============================================================================
# STEP 2: Descriptive Analysis
# ==============================================================================


def compute_descriptive_by_year(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute descriptive statistics by year.

    For each year, calculates:
        - n_papers: total number of papers
        - n_accepted: number accepted
        - acceptance_rate: proportion accepted
        - Mean and std for each language feature (for accepted and rejected)

    This helps detect dataset shifts, outlier years, and changes in review style.
    """
    rows = []
    for year in sorted(df["year"].unique()):
        year_df = df[df["year"] == year]
        accepted = year_df[year_df["decision"] == 1]
        rejected = year_df[year_df["decision"] == 0]

        row = {
            "year": year,
            "n_papers": len(year_df),
            "n_accepted": len(accepted),
            "n_rejected": len(rejected),
            "acceptance_rate": len(accepted) / len(year_df) if len(year_df) > 0 else 0,
        }

        for feat in CORE_LANGUAGE_FEATURES:
            row[f"{feat}_mean"] = year_df[feat].mean()
            row[f"{feat}_std"] = year_df[feat].std()
            row[f"{feat}_accept_mean"] = accepted[feat].mean()
            row[f"{feat}_reject_mean"] = rejected[feat].mean()
            row[f"{feat}_diff"] = accepted[feat].mean() - rejected[feat].mean()

        rows.append(row)

    return pd.DataFrame(rows)


def compute_descriptive_by_disagreement(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute descriptive statistics by disagreement level.

    For each disagreement level (low/medium/high), calculates:
        - Sample sizes and acceptance rates
        - Mean language features for accepted vs rejected
        - Difference in language features between groups

    This helps understand how language-acceptance relationships vary
    by reviewer agreement level.
    """
    rows = []
    for level in ["low", "medium", "high"]:
        level_df = df[df["disagreement_level"] == level]
        if len(level_df) == 0:
            continue

        accepted = level_df[level_df["decision"] == 1]
        rejected = level_df[level_df["decision"] == 0]

        row = {
            "disagreement_level": level,
            "n_papers": len(level_df),
            "n_accepted": len(accepted),
            "n_rejected": len(rejected),
            "acceptance_rate": len(accepted) / len(level_df) if len(level_df) > 0 else 0,
            "mean_score_std": level_df["score_std"].mean(),
        }

        for feat in CORE_LANGUAGE_FEATURES:
            row[f"{feat}_accept_mean"] = accepted[feat].mean()
            row[f"{feat}_reject_mean"] = rejected[feat].mean()
            row[f"{feat}_diff"] = accepted[feat].mean() - rejected[feat].mean()

        rows.append(row)

    return pd.DataFrame(rows)


def plot_acceptance_rate_by_year(df: pd.DataFrame) -> None:
    """
    Create line plot showing acceptance rate trends across years.

    Helps identify if acceptance standards changed over time.
    """
    desc = compute_descriptive_by_year(df)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(desc["year"], desc["acceptance_rate"], marker="o", linewidth=2)
    ax.set_xlabel("Year")
    ax.set_ylabel("Acceptance Rate")
    ax.set_title("ICLR Acceptance Rate by Year")
    ax.set_ylim(0, 1)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(OUT_DIR / "acceptance_rate_by_year.png", dpi=200)
    plt.close(fig)


def plot_language_features_by_year(df: pd.DataFrame) -> None:
    """
    Create boxplots of language features by year and decision.

    Visualizes whether language-decision relationships are consistent across years.
    """
    for feat in CORE_LANGUAGE_FEATURES:
        fig, ax = plt.subplots(figsize=(12, 5))
        plot_df = df[["year", "decision_label", feat]].copy()
        sns.boxplot(
            data=plot_df,
            x="year",
            y=feat,
            hue="decision_label",
            palette={"accept": "#1b9e77", "reject": "#d95f02"},
            ax=ax,
        )
        ax.set_title(f"{feat} by Year and Decision")
        ax.set_xlabel("Year")
        ax.set_ylabel(feat)
        ax.legend(title="Decision")
        fig.tight_layout()
        fig.savefig(OUT_DIR / f"{feat}_by_year_decision.png", dpi=200)
        plt.close(fig)


def plot_language_features_by_disagreement(df: pd.DataFrame) -> None:
    """
    Create boxplots of language features by disagreement level and decision.

    Visualizes H3c: whether language effects differ by reviewer agreement level.
    """
    for feat in CORE_LANGUAGE_FEATURES:
        fig, ax = plt.subplots(figsize=(10, 5))
        plot_df = df[["disagreement_level", "decision_label", feat]].copy()
        sns.boxplot(
            data=plot_df,
            x="disagreement_level",
            y=feat,
            hue="decision_label",
            order=["low", "medium", "high"],
            palette={"accept": "#1b9e77", "reject": "#d95f02"},
            ax=ax,
        )
        ax.set_title(f"{feat} by Disagreement Level and Decision")
        ax.set_xlabel("Disagreement Level (score_std terciles)")
        ax.set_ylabel(feat)
        ax.legend(title="Decision")
        fig.tight_layout()
        fig.savefig(OUT_DIR / f"{feat}_by_disagreement.png", dpi=200)
        plt.close(fig)


# ==============================================================================
# STEP 3: Stratified Logistic Regression
# ==============================================================================


def fit_logistic_regression(
    df: pd.DataFrame,
    features: List[str],
    outcome: str = "decision",
) -> Tuple[pd.DataFrame, float]:
    """
    Fit a logistic regression model and return coefficient table.

    Args:
        df: DataFrame with outcome and features
        features: List of feature column names
        outcome: Name of binary outcome column

    Returns:
        Tuple of (coefficient DataFrame, pseudo R-squared)
    """
    work = df[[outcome] + features].dropna()
    if len(work) < 20:
        return pd.DataFrame(), np.nan

    y = work[outcome].astype(int)
    X = work[features].copy()

    # Standardize features for comparable coefficients
    X = (X - X.mean()) / X.std()
    X = sm.add_constant(X, has_constant="add")

    try:
        model = sm.Logit(y, X).fit(disp=False, maxiter=300)
    except Exception:
        return pd.DataFrame(), np.nan

    coef_df = pd.DataFrame(
        {
            "feature": model.params.index,
            "coef": model.params.values,
            "std_err": model.bse.values,
            "z": model.tvalues.values,
            "pvalue": model.pvalues.values,
            "ci_low": model.conf_int()[0].values,
            "ci_high": model.conf_int()[1].values,
        }
    )
    coef_df["odds_ratio"] = np.exp(coef_df["coef"])
    coef_df["or_ci_low"] = np.exp(coef_df["ci_low"])
    coef_df["or_ci_high"] = np.exp(coef_df["ci_high"])
    coef_df["n"] = len(work)

    return coef_df, float(model.prsquared)


def stratified_regression_by_year(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fit separate logistic regression for each year (H3a: stability across years).

    Model: accept ~ quality_proxies + language_features

    Compares coefficient signs, sizes, and confidence intervals across years
    to assess temporal stability of language-acceptance relationships.
    """
    features = QUALITY_PROXIES + CORE_LANGUAGE_FEATURES
    all_results = []

    for year in sorted(df["year"].unique()):
        year_df = df[df["year"] == year]
        coef_df, pseudo_r2 = fit_logistic_regression(year_df, features)

        if coef_df.empty:
            continue

        coef_df["year"] = year
        coef_df["pseudo_r2"] = pseudo_r2
        all_results.append(coef_df)

    if not all_results:
        return pd.DataFrame()

    return pd.concat(all_results, ignore_index=True)


def stratified_regression_by_disagreement(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fit separate logistic regression for each disagreement level (H3c).

    Model: accept ~ quality_proxies + language_features

    Tests whether language effects are stronger when reviewer disagreement is high,
    i.e., when scores alone are less decisive.
    """
    features = QUALITY_PROXIES + CORE_LANGUAGE_FEATURES
    all_results = []

    for level in ["low", "medium", "high"]:
        level_df = df[df["disagreement_level"] == level]
        coef_df, pseudo_r2 = fit_logistic_regression(level_df, features)

        if coef_df.empty:
            continue

        coef_df["disagreement_level"] = level
        coef_df["pseudo_r2"] = pseudo_r2
        all_results.append(coef_df)

    if not all_results:
        return pd.DataFrame()

    return pd.concat(all_results, ignore_index=True)


def plot_coefficient_comparison_by_year(results_df: pd.DataFrame) -> None:
    """
    Create forest plot comparing language feature coefficients across years.

    Visualizes stability: if coefficients are similar across years, the
    relationship is stable.
    """
    for feat in CORE_LANGUAGE_FEATURES:
        feat_df = results_df[results_df["feature"] == feat].copy()
        if feat_df.empty:
            continue

        fig, ax = plt.subplots(figsize=(8, 5))
        years = feat_df["year"].values
        coefs = feat_df["coef"].values
        ci_low = feat_df["ci_low"].values
        ci_high = feat_df["ci_high"].values

        y_pos = np.arange(len(years))
        ax.errorbar(
            coefs,
            y_pos,
            xerr=[coefs - ci_low, ci_high - coefs],
            fmt="o",
            capsize=4,
            color="#1f77b4",
        )
        ax.axvline(x=0, color="gray", linestyle="--", alpha=0.5)
        ax.set_yticks(y_pos)
        ax.set_yticklabels([str(int(y)) for y in years])
        ax.set_xlabel("Coefficient (95% CI)")
        ax.set_ylabel("Year")
        ax.set_title(f"{feat}: Coefficient Stability Across Years")
        fig.tight_layout()
        fig.savefig(OUT_DIR / f"{feat}_coef_by_year.png", dpi=200)
        plt.close(fig)


# ==============================================================================
# STEP 4: Pooled Interaction Models
# ==============================================================================


def fit_interaction_model_year(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fit pooled logistic regression with language × year interactions.

    Model: accept ~ quality_proxies + language + year + language×year

    Tests H3a: If language×year interactions are small/non-significant,
    this supports temporal stability.
    """
    work = df.copy()

    # Create year dummies (reference = 2018)
    work["year_cat"] = work["year"].astype(str)
    year_dummies = pd.get_dummies(work["year_cat"], prefix="year", drop_first=True)

    # Main effects
    features = QUALITY_PROXIES + CORE_LANGUAGE_FEATURES
    X = work[features].copy()

    # Standardize continuous features
    for col in X.columns:
        X[col] = (X[col] - X[col].mean()) / X[col].std()

    # Add year dummies
    X = pd.concat([X, year_dummies], axis=1)

    # Add interaction terms: language × year
    for feat in CORE_LANGUAGE_FEATURES:
        for year_col in year_dummies.columns:
            interaction_name = f"{feat}_x_{year_col}"
            X[interaction_name] = X[feat] * year_dummies[year_col]

    X = sm.add_constant(X, has_constant="add")
    y = work["decision"].astype(int)

    # Drop rows with missing values
    valid = X.notna().all(axis=1) & y.notna()
    X = X[valid]
    y = y[valid]

    try:
        model = sm.Logit(y, X).fit(disp=False, maxiter=500)
    except Exception as e:
        print(f"[WARN] Interaction model failed: {e}")
        return pd.DataFrame()

    coef_df = pd.DataFrame(
        {
            "feature": model.params.index,
            "coef": model.params.values,
            "std_err": model.bse.values,
            "z": model.tvalues.values,
            "pvalue": model.pvalues.values,
            "ci_low": model.conf_int()[0].values,
            "ci_high": model.conf_int()[1].values,
        }
    )
    coef_df["odds_ratio"] = np.exp(coef_df["coef"])
    coef_df["or_ci_low"] = np.exp(coef_df["ci_low"])
    coef_df["or_ci_high"] = np.exp(coef_df["ci_high"])
    coef_df["n"] = len(y)
    coef_df["pseudo_r2"] = float(model.prsquared)

    return coef_df


def fit_interaction_model_disagreement(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fit pooled logistic regression with language × disagreement interactions.

    Model: accept ~ quality_proxies + language + disagreement + language×disagreement

    Tests H3c: If language×disagreement interactions are positive and significant,
    language matters more when reviewers disagree.
    """
    work = df.copy()

    # Create disagreement dummies (reference = low)
    disagree_dummies = pd.get_dummies(
        work["disagreement_level"], prefix="disagree", drop_first=True
    )

    # Main effects (exclude score_std as it's used to define disagreement)
    features = ["mean_score", "mean_confidence", "num_reviews"] + CORE_LANGUAGE_FEATURES
    X = work[features].copy()

    # Standardize continuous features
    for col in X.columns:
        X[col] = (X[col] - X[col].mean()) / X[col].std()

    # Add disagreement dummies
    X = pd.concat([X, disagree_dummies], axis=1)

    # Add interaction terms: language × disagreement
    for feat in CORE_LANGUAGE_FEATURES:
        for disagree_col in disagree_dummies.columns:
            interaction_name = f"{feat}_x_{disagree_col}"
            X[interaction_name] = X[feat] * disagree_dummies[disagree_col]

    X = sm.add_constant(X, has_constant="add")
    y = work["decision"].astype(int)

    # Drop rows with missing values
    valid = X.notna().all(axis=1) & y.notna()
    X = X[valid]
    y = y[valid]

    try:
        model = sm.Logit(y, X).fit(disp=False, maxiter=500)
    except Exception as e:
        print(f"[WARN] Disagreement interaction model failed: {e}")
        return pd.DataFrame()

    coef_df = pd.DataFrame(
        {
            "feature": model.params.index,
            "coef": model.params.values,
            "std_err": model.bse.values,
            "z": model.tvalues.values,
            "pvalue": model.pvalues.values,
            "ci_low": model.conf_int()[0].values,
            "ci_high": model.conf_int()[1].values,
        }
    )
    coef_df["odds_ratio"] = np.exp(coef_df["coef"])
    coef_df["or_ci_low"] = np.exp(coef_df["ci_low"])
    coef_df["or_ci_high"] = np.exp(coef_df["ci_high"])
    coef_df["n"] = len(y)
    coef_df["pseudo_r2"] = float(model.prsquared)

    return coef_df


# ==============================================================================
# STEP 5: Cross-Year Validation
# ==============================================================================


def evaluate_model_predictions(
    y_true: np.ndarray, y_prob: np.ndarray
) -> Dict[str, float]:
    """
    Compute evaluation metrics for model predictions.

    Metrics:
        - AUC-ROC: discrimination ability
        - Log loss: probabilistic calibration
        - Brier score: probability accuracy
    """
    return {
        "auc": roc_auc_score(y_true, y_prob),
        "log_loss": log_loss(y_true, y_prob),
        "brier_score": brier_score_loss(y_true, y_prob),
    }


def cross_year_validation(df: pd.DataFrame) -> pd.DataFrame:
    """
    Perform leave-one-year-out cross-validation.

    For each year:
        - Train on all other years
        - Test on held-out year
        - Compare model with vs without language features

    This tests reproducibility: if language features improve prediction
    consistently across held-out years, the relationship is reproducible.
    """
    results = []

    for test_year in sorted(df["year"].unique()):
        train_df = df[df["year"] != test_year]
        test_df = df[df["year"] == test_year]

        if len(test_df) < 20 or len(train_df) < 50:
            continue

        # Model 1: Quality proxies only (baseline)
        baseline_features = QUALITY_PROXIES
        # Model 2: Quality proxies + language features
        full_features = QUALITY_PROXIES + CORE_LANGUAGE_FEATURES

        for model_name, features in [
            ("baseline", baseline_features),
            ("with_language", full_features),
        ]:
            work_train = train_df[["decision"] + features].dropna()
            work_test = test_df[["decision"] + features].dropna()

            if len(work_train) < 20 or len(work_test) < 10:
                continue

            y_train = work_train["decision"].astype(int)
            X_train = work_train[features].copy()

            # Compute train stats for standardization
            train_mean = X_train.mean()
            train_std = X_train.std()
            train_std = train_std.replace(0, 1)  # Avoid division by zero

            X_train = (X_train - train_mean) / train_std
            X_train = sm.add_constant(X_train, has_constant="add")

            try:
                model = sm.Logit(y_train, X_train).fit(disp=False, maxiter=300)
            except Exception:
                continue

            y_test = work_test["decision"].astype(int)
            X_test = work_test[features].copy()
            X_test = (X_test - train_mean) / train_std
            X_test = sm.add_constant(X_test, has_constant="add")

            try:
                y_prob = model.predict(X_test)
            except Exception:
                continue

            metrics = evaluate_model_predictions(y_test.values, y_prob.values)
            metrics["test_year"] = test_year
            metrics["model"] = model_name
            metrics["n_train"] = len(work_train)
            metrics["n_test"] = len(work_test)
            results.append(metrics)

    return pd.DataFrame(results)


def compute_language_improvement(cv_results: pd.DataFrame) -> pd.DataFrame:
    """
    Compute improvement from adding language features.

    For each test year, computes:
        - Delta AUC: AUC(with_language) - AUC(baseline)
        - Delta log loss: log_loss(baseline) - log_loss(with_language)
        - Delta Brier: brier(baseline) - brier(with_language)

    Positive values indicate language features help.
    """
    rows = []
    for test_year in cv_results["test_year"].unique():
        year_results = cv_results[cv_results["test_year"] == test_year]
        baseline = year_results[year_results["model"] == "baseline"].iloc[0]
        with_lang = year_results[year_results["model"] == "with_language"].iloc[0]

        rows.append(
            {
                "test_year": test_year,
                "delta_auc": with_lang["auc"] - baseline["auc"],
                "delta_log_loss": baseline["log_loss"] - with_lang["log_loss"],
                "delta_brier": baseline["brier_score"] - with_lang["brier_score"],
                "baseline_auc": baseline["auc"],
                "with_language_auc": with_lang["auc"],
            }
        )

    return pd.DataFrame(rows)


# ==============================================================================
# STEP 6: Meta-Analysis
# ==============================================================================


def compute_meta_analysis(stratified_results: pd.DataFrame) -> pd.DataFrame:
    """
    Perform random-effects meta-analysis of year-specific coefficients.

    For each language feature:
        1. Collect year-specific coefficient estimates and standard errors
        2. Compute pooled effect using inverse-variance weighting
        3. Compute heterogeneity statistics (Q, I^2)

    Interpretation:
        - Low I^2 (< 25%): consistent effects across years
        - Moderate I^2 (25-75%): some heterogeneity
        - High I^2 (> 75%): substantial heterogeneity
    """
    results = []

    for feat in CORE_LANGUAGE_FEATURES:
        feat_df = stratified_results[stratified_results["feature"] == feat].copy()
        feat_df = feat_df.dropna(subset=["coef", "std_err"])

        if len(feat_df) < 2:
            continue

        # Extract estimates and standard errors
        effects = feat_df["coef"].values
        se = feat_df["std_err"].values
        se = np.where(se <= 0, 0.001, se)  # Avoid zero SE

        # Inverse-variance weights
        weights = 1.0 / (se**2)

        # Fixed-effect pooled estimate
        pooled_fe = np.sum(weights * effects) / np.sum(weights)
        pooled_se_fe = np.sqrt(1.0 / np.sum(weights))

        # Q statistic for heterogeneity
        Q = np.sum(weights * (effects - pooled_fe) ** 2)
        df = len(effects) - 1
        Q_pvalue = 1 - stats.chi2.cdf(Q, df) if df > 0 else np.nan

        # I^2 statistic
        I2 = max(0, (Q - df) / Q) * 100 if Q > 0 else 0

        # Random-effects model (DerSimonian-Laird)
        tau2 = max(0, (Q - df) / (np.sum(weights) - np.sum(weights**2) / np.sum(weights)))
        weights_re = 1.0 / (se**2 + tau2)
        pooled_re = np.sum(weights_re * effects) / np.sum(weights_re)
        pooled_se_re = np.sqrt(1.0 / np.sum(weights_re))

        results.append(
            {
                "feature": feat,
                "n_years": len(effects),
                "pooled_effect_fe": pooled_fe,
                "pooled_se_fe": pooled_se_fe,
                "pooled_effect_re": pooled_re,
                "pooled_se_re": pooled_se_re,
                "Q_statistic": Q,
                "Q_df": df,
                "Q_pvalue": Q_pvalue,
                "I2_percent": I2,
                "tau2": tau2,
                "min_effect": effects.min(),
                "max_effect": effects.max(),
                "effect_range": effects.max() - effects.min(),
            }
        )

    return pd.DataFrame(results)


def interpret_stability(meta_results: pd.DataFrame) -> pd.DataFrame:
    """
    Interpret meta-analysis results in terms of stability.

    Based on rq3.md interpretation guidelines:
        - I^2 < 25%: stable relationship
        - I^2 25-75%: moderate heterogeneity
        - I^2 > 75%: unstable relationship
    """
    meta_results = meta_results.copy()

    def interpret_i2(i2):
        if i2 < 25:
            return "stable (low heterogeneity)"
        elif i2 < 75:
            return "partially stable (moderate heterogeneity)"
        else:
            return "unstable (high heterogeneity)"

    meta_results["stability_interpretation"] = meta_results["I2_percent"].apply(
        interpret_i2
    )
    return meta_results


# ==============================================================================
# Main Entry Point
# ==============================================================================


def main() -> None:
    """
    Main entry point for RQ3 analysis.

    Implements the 7-step workflow from rq3.md:
        1. Build analysis dataset (load from RQ1, add moderators)
        2. Descriptive analysis (by year, area, disagreement)
        3. Stratified logistic regression (per-subgroup models)
        4. Pooled interaction models (language * context interactions)
        5. Hierarchical models (random slopes for language effects)
        6. Cross-validation tests (temporal and cross-group)
        7. Robustness checks (alternative specifications)
    """
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # -------------------------------------------------------------------------
    # Step 1: Load and prepare dataset
    # -------------------------------------------------------------------------
    print("[INFO] Step 1: Loading and preparing dataset...")
    df = load_rq1_data()
    df = prepare_analysis_dataset(df)
    print(f"[INFO] Loaded {len(df)} papers from {df['year'].nunique()} years")

    # -------------------------------------------------------------------------
    # Step 2: Descriptive analysis
    # -------------------------------------------------------------------------
    print("[INFO] Step 2: Computing descriptive statistics...")

    desc_year = compute_descriptive_by_year(df)
    desc_year.to_csv(OUT_DIR / "descriptive_by_year.csv", index=False)
    print(f"[INFO] Saved descriptive_by_year.csv")

    desc_disagree = compute_descriptive_by_disagreement(df)
    desc_disagree.to_csv(OUT_DIR / "descriptive_by_disagreement.csv", index=False)
    print(f"[INFO] Saved descriptive_by_disagreement.csv")

    print("[INFO] Generating plots...")
    plot_acceptance_rate_by_year(df)
    plot_language_features_by_year(df)
    plot_language_features_by_disagreement(df)

    # -------------------------------------------------------------------------
    # Step 3: Stratified logistic regression
    # -------------------------------------------------------------------------
    print("[INFO] Step 3: Fitting stratified logistic regressions...")

    strat_year = stratified_regression_by_year(df)
    strat_year.to_csv(OUT_DIR / "stratified_logit_by_year.csv", index=False)
    print(f"[INFO] Saved stratified_logit_by_year.csv")

    strat_disagree = stratified_regression_by_disagreement(df)
    strat_disagree.to_csv(OUT_DIR / "stratified_logit_by_disagreement.csv", index=False)
    print(f"[INFO] Saved stratified_logit_by_disagreement.csv")

    if not strat_year.empty:
        plot_coefficient_comparison_by_year(strat_year)

    # -------------------------------------------------------------------------
    # Step 4: Pooled interaction models
    # -------------------------------------------------------------------------
    print("[INFO] Step 4: Fitting pooled interaction models...")

    interaction_year = fit_interaction_model_year(df)
    interaction_year.to_csv(OUT_DIR / "interaction_model_year.csv", index=False)
    print(f"[INFO] Saved interaction_model_year.csv")

    interaction_disagree = fit_interaction_model_disagreement(df)
    interaction_disagree.to_csv(
        OUT_DIR / "interaction_model_disagreement.csv", index=False
    )
    print(f"[INFO] Saved interaction_model_disagreement.csv")

    # -------------------------------------------------------------------------
    # Step 5: Cross-year validation
    # -------------------------------------------------------------------------
    print("[INFO] Step 5: Running cross-year validation...")

    cv_results = cross_year_validation(df)
    cv_results.to_csv(OUT_DIR / "cross_year_validation.csv", index=False)
    print(f"[INFO] Saved cross_year_validation.csv")

    if not cv_results.empty:
        improvement = compute_language_improvement(cv_results)
        improvement.to_csv(OUT_DIR / "language_improvement_by_year.csv", index=False)
        print(f"[INFO] Saved language_improvement_by_year.csv")

    # -------------------------------------------------------------------------
    # Step 6: Meta-analysis
    # -------------------------------------------------------------------------
    print("[INFO] Step 6: Performing meta-analysis...")

    if not strat_year.empty:
        meta_results = compute_meta_analysis(strat_year)
        meta_results = interpret_stability(meta_results)
        meta_results.to_csv(OUT_DIR / "meta_analysis_results.csv", index=False)
        print(f"[INFO] Saved meta_analysis_results.csv")

        # Print summary
        print("\n" + "=" * 60)
        print("META-ANALYSIS SUMMARY: Stability of Language Effects")
        print("=" * 60)
        for _, row in meta_results.iterrows():
            print(
                f"  {row['feature']}: I^2 = {row['I2_percent']:.1f}% "
                f"({row['stability_interpretation']})"
            )
        print("=" * 60 + "\n")

    print(f"[DONE] All outputs saved to: {OUT_DIR.resolve()}")


if __name__ == "__main__":
    main()