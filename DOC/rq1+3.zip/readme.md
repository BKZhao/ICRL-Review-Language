## 现在用的开源词表

- Sentiment：VADER + NLTK Opinion Lexicon + AFINN
- Toxicity：LDNOOBW + Google profanity list + profanity-filter + profanitas/abuse + HurtLex EN
- Politeness：ConvoKit politeness markers + `myeomans/politeness` 源码中的 marker（自动下载）
- Constructiveness：由开源 marker 类别自动派生（Reasoning / Agency / Request 等类别），无手写词条


## 当前结论（ICLR 2018-2023）

- `mean_sentiment` 与 accept 显著正相关（最稳定）OR=1.68，p<1e-50
- `mean_politeness` 与 accept 显著正相关 OR=1.28，p≈3.6e-14
- `mean_toxicity` 不显著 p≈0.35 accept/reject 均值几乎一样
- `mean_constructiveness` 单变量弱显著，多变量不显著  OR=0.87，p≈6.6e-06；但它的组间均值差很小（accept 比 reject 低 0.005）

constructiveness 和 politeness 相关性较高（约 0.46），容易出现抑制效应
constructiveness 的方向在当前特征定义下不稳健，需进一步校准
entiment 的 accept-reject 差在 2018-2023 每年都为正，且幅度稳定（约 +0.10 到 +0.16）
politeness 每年都是小幅正差


# RQ3

## Research Question

> Is the relationship between review language and acceptance stable and reproducible across years, research areas/tracks, and different levels of reviewer agreement?

## Hypotheses

- **H3a**: The association between review language and acceptance is broadly similar from ICLR 2018 to 2023 (temporal stability)
- **H3b**: The association differs somewhat by topic area/track, but main patterns remain directionally consistent
- **H3c**: The relationship is stronger when reviewer disagreement is high (language matters more when scores are contested)

---

## Input

| File                                      | Description                                                                                                                                                                                                                        |
|-------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `outputs/rq1/paper_level_rq1_dataset.csv` | Paper-level dataset from RQ1 containing: decision (binary), year, language features (mean_sentiment, mean_politeness, mean_toxicity, mean_constructiveness), quality proxies (mean_score, score_std, mean_confidence, num_reviews) |

## Output

| File                                               | Description                                         |
|----------------------------------------------------|-----------------------------------------------------|
| `outputs/rq3/descriptive_by_year.csv`              | Acceptance rates and language feature means by year |
| `outputs/rq3/descriptive_by_disagreement.csv`      | Statistics by disagreement level (low/medium/high)  |
| `outputs/rq3/stratified_logit_by_year.csv`         | Year-specific regression coefficients               |
| `outputs/rq3/stratified_logit_by_disagreement.csv` | Disagreement-group regression coefficients          |
| `outputs/rq3/interaction_model_year.csv`           | Language × year interaction model results           |
| `outputs/rq3/interaction_model_disagreement.csv`   | Language × disagreement interaction model results   |
| `outputs/rq3/cross_year_validation.csv`            | Leave-one-year-out cross-validation metrics         |
| `outputs/rq3/language_improvement_by_year.csv`     | Delta AUC/Brier from adding language features       |
| `outputs/rq3/meta_analysis_results.csv`            | Heterogeneity statistics (I², Q statistic)          |
| `outputs/rq3/*.png`                                | Visualization plots                                 |

---

## Method Overview

```
Step 1: Data Preparation
    └── Add disagreement levels (score_std terciles) + within-year standardization

Step 2: Descriptive Analysis
    └── Acceptance rates, language means by year and disagreement level

Step 3: Stratified Logistic Regression
    └── Separate models per year and per disagreement level

Step 4: Pooled Interaction Models
    └── Test language×year and language×disagreement interactions

Step 5: Cross-Year Validation
    └── Leave-one-year-out CV comparing baseline vs full model

Step 6: Meta-Analysis
    └── Random-effects meta-analysis of year-specific coefficients (I², Q)
```

---

## Function Reference

### Step 1: Data Loading and Preparation

| Function                     | Description                                                |
|------------------------------|------------------------------------------------------------|
| `load_rq1_data()`            | 从 RQ1 输出加载 paper-level 数据集                                 |
| `add_disagreement_levels()`  | 基于 score_std 三分位数创建 disagreement_level 列 (low/medium/high) |
| `standardize_within_year()`  | 在每年内对特征进行 z-score 标准化，消除年份间评审风格差异                          |
| `prepare_analysis_dataset()` | 整合数据准备流程：添加 disagreement level + 年内标准化                     |

### Step 2: Descriptive Analysis

| Function                                   | Description                           |
|--------------------------------------------|---------------------------------------|
| `compute_descriptive_by_year()`            | 计算每年的接受率、语言特征均值（分 accept/reject）      |
| `compute_descriptive_by_disagreement()`    | 按 disagreement level 分组计算统计量          |
| `plot_acceptance_rate_by_year()`           | 绘制接受率年度趋势折线图                          |
| `plot_language_features_by_year()`         | 绘制各语言特征按年份和决策分组的箱线图                   |
| `plot_language_features_by_disagreement()` | 绘制各语言特征按 disagreement level 和决策分组的箱线图 |

### Step 3: Stratified Logistic Regression

| Function                                  | Description                            |
|-------------------------------------------|----------------------------------------|
| `fit_logistic_regression()`               | 核心函数：拟合逻辑回归，返回系数、OR、置信区间               |
| `stratified_regression_by_year()`         | 按年份分层回归，检验 H3a（时间稳定性）                  |
| `stratified_regression_by_disagreement()` | 按 disagreement level 分层回归，检验 H3c（调节效应） |
| `plot_coefficient_comparison_by_year()`   | 森林图：展示各年份系数的稳定性                        |

### Step 4: Pooled Interaction Models

| Function                               | Description                                                                             |
|----------------------------------------|-----------------------------------------------------------------------------------------|
| `fit_interaction_model_year()`         | 拟合 `accept ~ quality + language + year + language×year`，直接检验语言效应是否随年份变化                 |
| `fit_interaction_model_disagreement()` | 拟合 `accept ~ quality + language + disagreement + language×disagreement`，检验语言效应是否在高分歧时更强 |

### Step 5: Cross-Year Validation

| Function                         | Description                                    |
|----------------------------------|------------------------------------------------|
| `evaluate_model_predictions()`   | 计算预测评估指标：AUC、log loss、Brier score              |
| `cross_year_validation()`        | 留一年交叉验证：比较 baseline（仅质量代理）vs full model（质量+语言） |
| `compute_language_improvement()` | 计算每年添加语言特征带来的 delta AUC/Brier 提升               |

### Step 6: Meta-Analysis

| Function                  | Description                        |
|---------------------------|------------------------------------|
| `compute_meta_analysis()` | 随机效应 meta 分析：计算 Q 统计量、I² 异质性指标     |
| `interpret_stability()`   | 解读 I²：<25% 稳定，25-75% 中等异质，>75% 不稳定 |

### Main Entry Point

| Function | Description                             |
|----------|-----------------------------------------|
| `main()` | 执行完整 6 步流程，保存所有 CSV 和图表到 `outputs/rq3/` |

---

## Interpretation Guidelines

| Scenario          | I² Value   | Interpretation    |
|-------------------|------------|-------------------|
| Strong stability  | < 25%      | 语言-接受关系在各年份间稳定可复现 |
| Partial stability | 25-75%     | 方向一致但强度有变化        |
| Instability       | > 75%      | 关系不稳定，某年份结论可能不可推广 |

---

## Results

### Dataset Summary

- **Total papers**: 5,922 papers across 6 years (ICLR 2018-2023)
- **Acceptance rate range**: 31.3% (2020) to 40.7% (2023)

### H3a: Temporal Stability (Meta-Analysis)

| Feature              | I²     | Q p-value | Pooled Effect (RE) | Stability Interpretation |
|----------------------|--------|-----------|-------------------|--------------------------|
| mean_sentiment       | 0.0%   | 0.953     | 0.019             | Stable (low heterogeneity) |
| mean_politeness      | 0.0%   | 0.613     | 0.089             | Stable (low heterogeneity) |
| mean_toxicity        | 14.4%  | 0.322     | 0.032             | Stable (low heterogeneity) |
| mean_constructiveness| 46.9%  | 0.110     | -0.024            | Partially stable (moderate heterogeneity) |

**Key finding**: Sentiment and politeness effects are highly stable across years (I² = 0%), while constructiveness shows moderate heterogeneity.

### Sentiment Difference by Year (Accept - Reject)

| Year | Acceptance Rate | Sentiment Diff | Politeness Diff |
|------|-----------------|----------------|-----------------|
| 2018 | 36.6%           | +0.145         | +0.009          |
| 2019 | 39.1%           | +0.156         | +0.005          |
| 2020 | 31.3%           | +0.143         | +0.007          |
| 2021 | 31.6%           | +0.097         | +0.008          |
| 2022 | 39.5%           | +0.103         | +0.006          |
| 2023 | 40.7%           | +0.116         | +0.007          |

**Key finding**: Accepted papers consistently receive reviews with higher sentiment scores across all 6 years.

### H3c: Disagreement Level Moderation

| Disagreement Level | n_papers | Acceptance Rate | Sentiment Diff (A-R) |
|--------------------|----------|-----------------|----------------------|
| Low (score_std < 0.72)  | 2,008    | 38.6%           | +0.123               |
| Medium                  | 2,006    | 40.7%           | +0.162               |
| High (score_std > 1.47) | 1,908    | 29.8%           | +0.077               |

**Key finding**: Contrary to H3c, the sentiment-acceptance relationship is actually *weaker* (not stronger) when disagreement is high. This may be because high-disagreement papers are borderline cases where other factors dominate.

### Cross-Year Validation (Leave-One-Year-Out)

| Test Year | Baseline AUC | With Language AUC | Δ AUC   |
|-----------|--------------|-------------------|---------|
| 2018      | 0.958        | 0.958             | -0.0002 |
| 2019      | 0.963        | 0.963             | -0.0003 |
| 2021      | 0.955        | 0.955             | -0.0003 |
| 2022      | 0.956        | 0.957             | +0.0002 |
| 2023      | 0.962        | 0.963             | +0.0007 |

**Key finding**: Adding language features provides negligible improvement in prediction (Δ AUC < 0.001), indicating that quality proxies (mean_score, score_std) already capture most predictive information.

---

## Conclusion

### Hypothesis Evaluation

| Hypothesis | Result | Evidence |
|------------|--------|----------|
| **H3a** (Temporal stability) | ✅ Supported | I² = 0% for sentiment and politeness; effect direction consistent across all 6 years |
| **H3b** (Cross-area stability) | ⚠️ Not tested | Area/track labels not available in current dataset |
| **H3c** (Disagreement moderation) | ❌ Not supported | Language effects are *weaker* (not stronger) under high disagreement |

### Summary

1. **Sentiment is the most stable predictor**: The positive association between review sentiment and acceptance is remarkably consistent across years (I² = 0%), with accepted papers receiving reviews ~0.10-0.16 higher in sentiment than rejected papers every year.

2. **Politeness shows similar stability**: Though the effect size is smaller, the positive association between politeness and acceptance is also stable across years.

3. **Constructiveness is less reliable**: With I² = 46.9%, the constructiveness-acceptance relationship varies more across years and its direction is inconsistent.

4. **Language features don't add predictive value**: Cross-validation shows that language features provide essentially no improvement over quality proxies (mean_score, score_std) for predicting acceptance, suggesting language correlates with but doesn't independently predict outcomes.

5. **High disagreement doesn't amplify language effects**: The hypothesis that language matters more when reviewers disagree was not supported; if anything, the opposite appears true.

