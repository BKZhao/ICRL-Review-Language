"""
Eval-RQ2: Incremental Explanatory Power of Review Language (PeerRead external set)
尽量复刻 rq2.py 的流程与输出文件命名。
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import chi2
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

try:
    import shap

    HAS_SHAP = True
except Exception:
    HAS_SHAP = False


PROJECT_ROOT = Path(__file__).resolve().parents[1]
INPUT_FILE = PROJECT_ROOT / "eval" / "outputs" / "rq1" / "paper_level_rq1_dataset.csv"
OUT_DIR = PROJECT_ROOT / "eval" / "outputs" / "rq2"

CONTROL_VARS = ["mean_score", "score_std", "num_reviews"]
LANGUAGE_VARS = ["mean_sentiment", "mean_politeness", "mean_toxicity", "mean_constructiveness"]
TARGET_VAR = "decision"

sns.set_theme(style="whitegrid")


def safe_auc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    if len(np.unique(y_true)) < 2:
        return np.nan
    return float(roc_auc_score(y_true, y_score))


def period_bucket(year: int) -> str:
    if year <= 2012:
        return "peerread_2007_2012"
    if year <= 2017:
        return "peerread_2013_2017"
    if year <= 2020:
        return "iclr_2018_2020"
    return "iclr_2021_2024"


def load_and_scale_data(filepath: Path) -> pd.DataFrame:
    print(f"[INFO] Loading data from {filepath}...")
    df = pd.read_csv(filepath)

    if "decision_label" in df.columns and df[TARGET_VAR].dtype == object:
        df[TARGET_VAR] = df["decision_label"].map({"accept": 1, "reject": 0})

    if "period_bucket" not in df.columns and "year" in df.columns:
        df["period_bucket"] = df["year"].astype(int).map(period_bucket)

    needed = CONTROL_VARS + LANGUAGE_VARS + [TARGET_VAR, "year"]
    df = df.dropna(subset=[c for c in needed if c in df.columns]).copy()

    features_to_scale = [c for c in CONTROL_VARS + LANGUAGE_VARS if c in df.columns]
    for col in features_to_scale:
        std = df[col].std(ddof=0)
        if std and not np.isnan(std) and std > 0:
            df[col] = (df[col] - df[col].mean()) / std
        else:
            df[col] = 0.0

    print(f"[INFO] Data loaded and scaled. Usable samples: {len(df)}")
    return df


def build_time_controls(df: pd.DataFrame, use_year: bool, use_venue: bool, use_period: bool) -> pd.DataFrame:
    controls = pd.DataFrame(index=df.index)
    if use_year and "year" in df.columns:
        controls = pd.concat(
            [controls, pd.get_dummies(df["year"].astype(str), prefix="year", drop_first=True, dtype=float)],
            axis=1,
        )
    if use_venue and "venue" in df.columns:
        controls = pd.concat(
            [controls, pd.get_dummies(df["venue"].astype(str), prefix="venue", drop_first=True, dtype=float)],
            axis=1,
        )
    if use_period and "period_bucket" in df.columns:
        controls = pd.concat(
            [
                controls,
                pd.get_dummies(
                    df["period_bucket"].astype(str),
                    prefix="period",
                    drop_first=True,
                    dtype=float,
                ),
            ],
            axis=1,
        )
    return controls


def fit_hierarchical_models(
    df: pd.DataFrame,
    use_year_fixed_effects: bool = False,
    use_venue_fixed_effects: bool = True,
    use_period_controls: bool = True,
) -> dict:
    y = df[TARGET_VAR].astype(float)

    x_base = df[CONTROL_VARS].copy()
    time_controls = build_time_controls(
        df,
        use_year=use_year_fixed_effects,
        use_venue=use_venue_fixed_effects,
        use_period=use_period_controls,
    )
    x_base = pd.concat([x_base, time_controls], axis=1)
    x_base = sm.add_constant(x_base, has_constant="add")

    x_full = pd.concat([x_base, df[LANGUAGE_VARS]], axis=1)

    try:
        base_model = sm.Logit(y, x_base).fit(disp=False, maxiter=500)
        full_model = sm.Logit(y, x_full).fit(disp=False, maxiter=500)

        base_llf = base_model.llf
        full_llf = full_model.llf
        base_r2 = float(base_model.prsquared)
        full_r2 = float(full_model.prsquared)

        base_pred = base_model.predict(x_base)
        full_pred = full_model.predict(x_full)
        base_auc = safe_auc(y.values, base_pred.values)
        full_auc = safe_auc(y.values, full_pred.values)

        lr_stat = -2 * (base_llf - full_llf)
        df_diff = float(full_model.df_model - base_model.df_model)
        p_value = chi2.sf(lr_stat, df_diff) if df_diff > 0 else np.nan

        return {
            "Base_R2": base_r2,
            "Full_R2": full_r2,
            "Delta_R2": full_r2 - base_r2,
            "Base_AUC": base_auc,
            "Full_AUC": full_auc,
            "Delta_AUC": full_auc - base_auc if not np.isnan(base_auc) and not np.isnan(full_auc) else np.nan,
            "LRT_Stat": float(lr_stat),
            "LRT_pvalue": float(p_value) if not np.isnan(p_value) else np.nan,
            "Significant": "Yes" if not np.isnan(p_value) and p_value < 0.05 else "No",
            "Control_Set": f"year_fe={use_year_fixed_effects};venue_fe={use_venue_fixed_effects};period={use_period_controls}",
        }
    except Exception as exc:
        print(f"[WARNING] Model fitting failed: {exc}")
        return {
            "Base_R2": np.nan,
            "Full_R2": np.nan,
            "Delta_R2": np.nan,
            "Base_AUC": np.nan,
            "Full_AUC": np.nan,
            "Delta_AUC": np.nan,
            "LRT_Stat": np.nan,
            "LRT_pvalue": np.nan,
            "Significant": "No",
            "Control_Set": f"year_fe={use_year_fixed_effects};venue_fe={use_venue_fixed_effects};period={use_period_controls}",
        }


def run_shapley_analysis(df: pd.DataFrame) -> None:
    print("\n[INFO] Step D: Running feature importance analysis...")
    x = df[CONTROL_VARS + LANGUAGE_VARS].copy()
    y = df[TARGET_VAR].astype(int)

    rf = RandomForestClassifier(n_estimators=200, max_depth=6, random_state=42, n_jobs=-1)
    rf.fit(x, y)

    if HAS_SHAP:
        explainer = shap.TreeExplainer(rf)
        shap_values = explainer.shap_values(x)
        if isinstance(shap_values, list):
            shap_vals_class1 = shap_values[1]
        elif len(shap_values.shape) == 3:
            shap_vals_class1 = shap_values[:, :, 1]
        else:
            shap_vals_class1 = shap_values
        importance_values = np.abs(shap_vals_class1).mean(axis=0)
        importance_col = "Mean_Abs_SHAP"
    else:
        print("[WARN] `shap` unavailable. Falling back to RF feature_importances_.")
        importance_values = rf.feature_importances_
        importance_col = "RF_Importance"

    importance = pd.DataFrame({"Feature": x.columns, importance_col: importance_values})
    lang_importance = importance[importance["Feature"].isin(LANGUAGE_VARS)].copy()
    total = lang_importance[importance_col].sum()
    if total <= 0:
        lang_importance["Relative_Contribution_%"] = 0.0
    else:
        lang_importance["Relative_Contribution_%"] = (lang_importance[importance_col] / total) * 100

    lang_importance = lang_importance.sort_values(by="Relative_Contribution_%", ascending=False)
    lang_importance.to_csv(OUT_DIR / "shapley_relative_importance.csv", index=False)

    plt.figure(figsize=(8, 5))
    sns.barplot(
        x="Relative_Contribution_%",
        y="Feature",
        hue="Feature",
        data=lang_importance,
        palette="viridis",
        dodge=False,
        legend=False,
    )
    plt.title("Relative Contribution of Language Features")
    plt.xlabel("Relative Contribution (%)")
    plt.ylabel("")
    plt.tight_layout()
    plt.savefig(OUT_DIR / "shapley_importance_bar.png", dpi=300)
    plt.close()


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    df = load_and_scale_data(INPUT_FILE)
    if df.empty:
        print("[ERROR] No valid data after preprocessing. Exiting.")
        return

    print("\n[INFO] Step B & C: Pooled analysis...")
    pooled_res = fit_hierarchical_models(
        df,
        use_year_fixed_effects=True,
        use_venue_fixed_effects=True,
        use_period_controls=True,
    )
    pooled_df = pd.DataFrame([pooled_res])
    pooled_df.to_csv(OUT_DIR / "pooled_r2_auc_comparison.csv", index=False)

    print(f"  Base R2={pooled_res['Base_R2']:.4f}, Full R2={pooled_res['Full_R2']:.4f}, Delta R2={pooled_res['Delta_R2']:.4f}")
    print(f"  Base AUC={pooled_res['Base_AUC']:.4f}, Full AUC={pooled_res['Full_AUC']:.4f}, Delta AUC={pooled_res['Delta_AUC']:.4f}")
    print(f"  LRT p-value={pooled_res['LRT_pvalue']:.3e} (Significant={pooled_res['Significant']})")

    print("\n[INFO] Step C: Year-by-year analysis...")
    yearly_records = []
    for year in sorted(df["year"].unique()):
        year_df = df[df["year"] == year].copy()
        res = fit_hierarchical_models(
            year_df,
            use_year_fixed_effects=False,
            use_venue_fixed_effects=True,
            use_period_controls=False,
        )
        yearly_records.append({"Year": int(year), **res})

    yearly_results_df = pd.DataFrame(yearly_records)
    yearly_results_df.to_csv(OUT_DIR / "yearly_r2_auc_comparison.csv", index=False)
    print(f"[INFO] Saved yearly results to {OUT_DIR / 'yearly_r2_auc_comparison.csv'}")

    run_shapley_analysis(df)
    print(f"\n[DONE] Eval-RQ2 complete. Outputs saved to: {OUT_DIR.resolve()}")


if __name__ == "__main__":
    main()
