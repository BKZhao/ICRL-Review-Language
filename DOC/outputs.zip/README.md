# Eval Pipeline (RQ1 / RQ2 / RQ3)

This folder mirrors the main analysis flow under `rq1_iclr_analysis.py`, `rq2.py`, and `rq3.py`, but targets external validation with PeerRead data.

## Scripts

- `rq1_eval.py`: Build PeerRead paper-level dataset and run RQ1-style outputs.
- `rq2_eval.py`: Incremental explanatory power analysis on eval-RQ1 dataset.
- `rq3_eval.py`: Stability/reproducibility analysis on combined ICLR + PeerRead data.
- `run_all_eval.py`: Run `rq1 -> rq2 -> rq3` in sequence.

## Output layout

- `eval/outputs/rq1`
- `eval/outputs/rq2`
- `eval/outputs/rq3`

Each subfolder keeps filenames close to the corresponding original RQ script outputs.
