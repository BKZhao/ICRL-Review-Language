from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from rq1_iclr_analysis import (  # noqa: E402
    extract_leading_number,
    extract_text_features,
)


PEERREAD_DIR = PROJECT_ROOT / "data"
ACL_ACCEPTED_FILE = PEERREAD_DIR / "acl_accepted.txt"

DATASET_DEFAULT_YEAR = {
    "iclr_2017": 2017,
    "acl_2017": 2017,
    "conll_2016": 2016,
}


def normalize_title(title: str) -> str:
    title = str(title).strip().lower()
    title = re.sub(r"[^a-z0-9]+", " ", title)
    return " ".join(title.split())


def parse_year(record: Dict, subset: str, paper_id: str) -> Optional[int]:
    date_str = record.get("DATE_OF_SUBMISSION")
    if isinstance(date_str, str):
        match = re.search(r"(19|20)\d{2}", date_str)
        if match:
            return int(match.group())

    arxiv_match = re.match(r"^(\d{2})(\d{2})\.", str(paper_id))
    if arxiv_match:
        return 2000 + int(arxiv_match.group(1))

    return DATASET_DEFAULT_YEAR.get(subset)


def period_bucket(year: Optional[int]) -> str:
    if year is None or pd.isna(year):
        return "unknown"
    year_int = int(year)
    if year_int <= 2012:
        return "peerread_2007_2012"
    if year_int <= 2017:
        return "peerread_2013_2017"
    if year_int <= 2020:
        return "iclr_2018_2020"
    return "iclr_2021_2024"


def parse_numeric(value) -> float:
    if value is None:
        return np.nan
    if isinstance(value, (int, float)) and not pd.isna(value):
        return float(value)
    return extract_leading_number(str(value))


def is_meta_review(review: Dict) -> bool:
    return bool(review.get("IS_META_REVIEW") or review.get("is_meta_review"))


def load_acl_accepted_titles(path: Path = ACL_ACCEPTED_FILE) -> set[str]:
    if not path.exists():
        return set()
    titles = set()
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        clean = normalize_title(line)
        if clean:
            titles.add(clean)
    return titles


def infer_decision(
    record: Dict,
    subset: str,
    acl_accepted_titles: set[str],
) -> Tuple[Optional[int], Optional[str]]:
    accepted = record.get("accepted")
    if accepted is not None:
        return int(bool(accepted)), "accepted_field"

    if subset == "acl_2017" and acl_accepted_titles:
        title = normalize_title(record.get("title", ""))
        if title:
            return int(title in acl_accepted_titles), "acl_accepted_title_list"

    return None, None


def collect_peerread_records(
    subsets: Optional[List[str]] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if subsets is None:
        subsets = [
            "iclr_2017",
            "acl_2017",
            "conll_2016",
            "arxiv.cs.ai_2007-2017",
            "arxiv.cs.cl_2007-2017",
            "arxiv.cs.lg_2007-2017",
        ]

    acl_accepted_titles = load_acl_accepted_titles()
    paper_records: List[Dict] = []
    review_records: List[Dict] = []
    summary_rows: List[Dict] = []

    for subset in subsets:
        files = list((PEERREAD_DIR / subset).glob("**/reviews/*.json"))
        n_total = 0
        n_with_decision = 0
        n_with_text = 0
        n_kept = 0

        for file_path in files:
            n_total += 1
            try:
                record = json.loads(file_path.read_text(encoding="utf-8", errors="ignore"))
            except Exception:
                continue

            paper_id = str(record.get("id", file_path.stem))
            forum = f"{subset}:{paper_id}"
            year = parse_year(record, subset, paper_id)
            decision, decision_source = infer_decision(record, subset, acl_accepted_titles)
            if decision is not None:
                n_with_decision += 1

            reviews = record.get("reviews", [])
            if not isinstance(reviews, list):
                reviews = []

            dedup_texts = set()
            paper_review_rows = []
            for review in reviews:
                if not isinstance(review, dict) or is_meta_review(review):
                    continue
                text = str(review.get("comments", "")).strip()
                if not text:
                    continue

                dedup_key = re.sub(r"\s+", " ", text).strip().lower()
                if dedup_key in dedup_texts:
                    continue
                dedup_texts.add(dedup_key)

                rec = parse_numeric(review.get("RECOMMENDATION"))
                if pd.isna(rec):
                    rec = parse_numeric(review.get("RECOMMENDATION_UNOFFICIAL"))
                conf = parse_numeric(review.get("REVIEWER_CONFIDENCE"))

                paper_review_rows.append(
                    {
                        "Forum": forum,
                        "Content": text,
                        "recommendation": rec,
                        "confidence": conf,
                    }
                )

            if paper_review_rows:
                n_with_text += 1

            if decision is not None and paper_review_rows:
                n_kept += 1
                paper_records.append(
                    {
                        "Forum": forum,
                        "peerread_id": paper_id,
                        "title": record.get("title"),
                        "venue": subset,
                        "year": year,
                        "period_bucket": period_bucket(year),
                        "decision": int(decision),
                        "decision_source": decision_source,
                    }
                )
                review_records.extend(paper_review_rows)

        summary_rows.append(
            {
                "subset": subset,
                "papers_total": n_total,
                "papers_with_decision": n_with_decision,
                "papers_with_non_meta_text": n_with_text,
                "papers_kept_for_eval": n_kept,
            }
        )

    return (
        pd.DataFrame(paper_records),
        pd.DataFrame(review_records),
        pd.DataFrame(summary_rows),
    )


def build_peerread_paper_level(sia, lexicons) -> Tuple[pd.DataFrame, pd.DataFrame]:
    paper_df, review_df, ingest_summary = collect_peerread_records()
    if paper_df.empty or review_df.empty:
        return pd.DataFrame(), ingest_summary

    review_features = extract_text_features(review_df[["Forum", "Content"]], sia, lexicons)
    review_agg = (
        review_features.groupby("Forum", as_index=False)
        .agg(
            mean_sentiment=("sentiment_compound", "mean"),
            min_sentiment=("sentiment_compound", "min"),
            sentiment_std=("sentiment_compound", "std"),
            mean_positive_ratio=("sentiment_positive", "mean"),
            mean_negative_ratio=("sentiment_negative", "mean"),
            mean_politeness=("politeness", "mean"),
            mean_toxicity=("toxicity", "mean"),
            mean_constructiveness=("constructiveness", "mean"),
            num_reviews=("review_text", "count"),
            mean_review_length=("review_length_words", "mean"),
        )
        .fillna({"sentiment_std": 0.0})
    )

    score_agg = (
        review_df.groupby("Forum", as_index=False)
        .agg(
            mean_score=("recommendation", "mean"),
            score_std=("recommendation", "std"),
            score_count=("recommendation", "count"),
            mean_confidence=("confidence", "mean"),
            confidence_std=("confidence", "std"),
            confidence_count=("confidence", "count"),
        )
        .fillna({"score_std": 0.0, "confidence_std": 0.0})
    )

    out = paper_df.merge(review_agg, on="Forum", how="left").merge(score_agg, on="Forum", how="left")
    out["decision_label"] = out["decision"].map({1: "accept", 0: "reject"})
    out = out[out["num_reviews"].fillna(0) > 0].copy()
    return out, ingest_summary
