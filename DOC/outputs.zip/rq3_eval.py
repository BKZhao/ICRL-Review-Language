"""
Eval-RQ3: Stability and Reproducibility (ICLR main data + PeerRead external data)
尽量复刻 rq3.py 的流程与输出，并加入 source/time controls。
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib
import numpy as np
import pandas as pd
import seaborn as sns
import statsmodels.api as sm
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score

matplotlib.use("Agg")
import matplotlib.pyplot as plt


PROJECT_ROOT = Path(__file__).resolve().parents[1]
ICLR_RQ1_FILE = PROJECT_ROOT / "outputs" / "rq1" / "paper_level_rq1_dataset.csv"
PEERREAD_RQ1_FILE = PROJECT_ROOT / "eval" / "outputs" / "rq1" / "paper_level_rq1_dataset.csv"
OUT_DIR = PROJECT_ROOT / "eval" / "outputs" / "rq3"

CORE_LANGUAGE_FEATURES = [
    "mean_sentiment",
    "mean_politeness",
    "mean_toxicity",
    "mean_constructiveness",
]
QUALITY_PROXIES = ["mean_score", "score_std", "mean_confidence", "num_reviews"]


def period_bucket(year: int) -> str:
    if year <= 2012:
        return "peerread_2007_2012"
    if year <= 2017:
        return "peerread_2013_2017"
    if year <= 2020:
        return "iclr_2018_2020"
    return "iclr_2021_2024"


def ensure_eval_rq1_dataset() -> None:
    if PEERREAD_RQ1_FILE.exists():
        return
    print("[INFO] Eval RQ1 dataset not found. Running rq1_eval.py first...")
    subprocess.run([sys.executable, str(PROJECT_ROOT / "eval" / "rq1_eval.py")], check=True)


def load_combined_rq1_data() -> pd.DataFrame:
    ensure_eval_rq1_dataset()

    iclr = pd.read_csv(ICLR_RQ1_FILE)
    iclr = iclr[iclr["decision"].notna()].copy()
    iclr["decision"] = iclr["decision"].astype(int)
    iclr["source_domain"] = "iclr"
    iclr["venue"] = "iclr_2018_2023"

    peer = pd.read_csv(PEERREAD_RQ1_FILE)
    peer = peer[peer["decision"].notna()].copy()
    peer["decision"] = peer["decision"].astype(int)
    peer["source_domain"] = "peerread"

    needed = (
        ["decision", "year", "source_domain", "venue", "decision_label"]
        + CORE_LANGUAGE_FEATURES
        + QUALITY_PROXIES
    )
    for col in needed:
        if col not in iclr.columns:
            iclr[col] = np.nan
        if col not in peer.columns:
            peer[col] = np.nan

    df = pd.concat([iclr[needed], peer[needed]], ignore_index=True)
    df = df.dropna(subset=["decision", "year"]).copy()
    df["year"] = df["year"].astype(int)
    df["period_bucket"] = df["year"].map(period_bucket)
    if "decision_label" not in df.columns or df["decision_label"].isna().all():
        df["decision_label"] = df["decision"].map({1: "accept", 0: "reject"})
    else:
        df["decision_label"] = df["decision_label"].fillna(df["decision"].map({1: "accept", 0: "reject"}))
    return df


def add_disagreement_levels(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["score_std"] = out["score_std"].fillna(0)
    terciles = out["score_std"].quantile([0.33, 0.67])
    out["disagreement_level"] = pd.cut(
        out["score_std"],
        bins=[-np.inf, terciles.iloc[0], terciles.iloc[1], np.inf],
        labels=["low", "medium", "high"],
    )
    return out


def standardize_within_year(df: pd.DataFrame, features: List[str]) -> pd.DataFrame:
    out = df.copy()
    for feat in features:
        if feat not in out.columns:
            continue
        out[f"{feat}_std"] = out.groupby("year")[feat].transform(
            lambda x: (x - x.mean()) / x.std(ddof=0) if x.std(ddof=0) > 0 else 0.0
        )
    return out


def prepare_analysis_dataset(df: pd.DataFrame) -> pd.DataFrame:
    out = add_disagreement_levels(df)
    out = standardize_within_year(out, CORE_LANGUAGE_FEATURES + QUALITY_PROXIES)
    out["year_cat"] = out["year"].astype(str)
    out["source_cat"] = out["source_domain"].astype(str)
    return out


def compute_descriptive_by_year(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for year in sorted(df["year"].unique()):
        year_df = df[df["year"] == year]
        accepted = year_df[year_df["decision"] == 1]
        rejected = year_df[year_df["decision"] == 0]

        row = {
            "year": int(year),
            "n_papers": int(len(year_df)),
            "n_accepted": int(len(accepted)),
            "n_rejected": int(len(rejected)),
            "acceptance_rate": float(year_df["decision"].mean()) if len(year_df) > 0 else np.nan,
            "source_domain": year_df["source_domain"].mode().iloc[0] if len(year_df) > 0 else np.nan,
        }
        for feat in CORE_LANGUAGE_FEATURES:
            row[f"{feat}_mean"] = year_df[feat].mean()
            row[f"{feat}_std"] = year_df[feat].std()
            row[f"{feat}_accept_mean"] = accepted[feat].mean()
            row[f"{feat}_reject_mean"] = rejected[feat].mean()
            row[f"{feat}_diff"] = accepted[feat].mean() - rejected[feat].mean()
        rows.append(row)

    return pd.DataFrame(rows)


def compute_descriptive_by_disagreement(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for level in ["low", "medium", "high"]:
        level_df = df[df["disagreement_level"] == level]
        accepted = level_df[level_df["decision"] == 1]
        rejected = level_df[level_df["decision"] == 0]

        row = {
            "disagreement_level": level,
            "n_papers": int(len(level_df)),
            "n_accepted": int(len(accepted)),
            "n_rejected": int(len(rejected)),
            "acceptance_rate": float(level_df["decision"].mean()) if len(level_df) > 0 else np.nan,
        }
        for feat in CORE_LANGUAGE_FEATURES:
            row[f"{feat}_mean"] = level_df[feat].mean()
            row[f"{feat}_accept_mean"] = accepted[feat].mean()
            row[f"{feat}_reject_mean"] = rejected[feat].mean()
            row[f"{feat}_diff"] = accepted[feat].mean() - rejected[feat].mean()
        rows.append(row)
    return pd.DataFrame(rows)


def compute_descriptive_by_source(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for source, group in df.groupby("source_domain"):
        row = {
            "source_domain": source,
            "n_papers": int(len(group)),
            "n_accepted": int(group["decision"].sum()),
            "acceptance_rate": float(group["decision"].mean()),
            "year_min": int(group["year"].min()),
            "year_max": int(group["year"].max()),
            "year_nunique": int(group["year"].nunique()),
        }
        for feat in CORE_LANGUAGE_FEATURES:
            row[f"{feat}_mean"] = group[feat].mean()
            row[f"{feat}_std"] = group[feat].std()
        rows.append(row)
    return pd.DataFrame(rows)


def plot_acceptance_rate_by_year(df: pd.DataFrame) -> None:
    desc = compute_descriptive_by_year(df)
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(desc["year"], desc["acceptance_rate"], marker="o", linewidth=2)
    ax.set_title("Acceptance Rate by Year (ICLR + PeerRead)")
    ax.set_xlabel("Year")
    ax.set_ylabel("Acceptance Rate")
    fig.tight_layout()
    fig.savefig(OUT_DIR / "acceptance_rate_by_year.png", dpi=200)
    plt.close(fig)


def plot_language_features_by_year(df: pd.DataFrame) -> None:
    for feat in CORE_LANGUAGE_FEATURES:
        fig, ax = plt.subplots(figsize=(10, 5))
        plot_df = df[["year", "decision_label", feat]].copy()
        sns.boxplot(
            data=plot_df,
            x="year",
            y=feat,
            hue="decision_label",
            palette={"accept": "#1b9e77", "reject": "#d95f02"},
            ax=ax,
        )
        ax.set_title(f"{feat} by Year and Decision")
        ax.set_xlabel("Year")
        ax.set_ylabel(feat)
        fig.tight_layout()
        fig.savefig(OUT_DIR / f"{feat}_by_year_decision.png", dpi=200)
        plt.close(fig)


def plot_language_features_by_disagreement(df: pd.DataFrame) -> None:
    for feat in CORE_LANGUAGE_FEATURES:
        fig, ax = plt.subplots(figsize=(10, 5))
        plot_df = df[["disagreement_level", "decision_label", feat]].copy()
        sns.boxplot(
            data=plot_df,
            x="disagreement_level",
            y=feat,
            hue="decision_label",
            order=["low", "medium", "high"],
            palette={"accept": "#1b9e77", "reject": "#d95f02"},
            ax=ax,
        )
        ax.set_title(f"{feat} by Disagreement Level and Decision")
        ax.set_xlabel("Disagreement Level")
        ax.set_ylabel(feat)
        fig.tight_layout()
        fig.savefig(OUT_DIR / f"{feat}_by_disagreement.png", dpi=200)
        plt.close(fig)


def fit_logistic_regression(df: pd.DataFrame, features: List[str], outcome: str = "decision") -> Tuple[pd.DataFrame, float]:
    work = df[[outcome] + features].dropna()
    if len(work) < 20:
        return pd.DataFrame(), np.nan

    y = work[outcome].astype(int)
    x = work[features].copy()
    x = sm.add_constant(x, has_constant="add")

    try:
        model = sm.GLM(y, x, family=sm.families.Binomial()).fit()
    except Exception:
        return pd.DataFrame(), np.nan

    coef_df = pd.DataFrame(
        {
            "feature": model.params.index,
            "coef": model.params.values,
            "std_err": model.bse.values,
            "z": model.tvalues.values,
            "pvalue": model.pvalues.values,
            "ci_low": model.conf_int()[0].values,
            "ci_high": model.conf_int()[1].values,
        }
    )
    coef_df["odds_ratio"] = np.exp(coef_df["coef"])
    coef_df["or_ci_low"] = np.exp(coef_df["ci_low"])
    coef_df["or_ci_high"] = np.exp(coef_df["ci_high"])
    coef_df["n"] = len(work)
    pseudo_r2 = 1 - (model.llf / model.llnull) if model.llnull != 0 else np.nan
    return coef_df, float(pseudo_r2)


def stratified_regression_by_year(df: pd.DataFrame) -> pd.DataFrame:
    features = [f"{f}_std" for f in QUALITY_PROXIES + CORE_LANGUAGE_FEATURES]
    all_results = []
    for year in sorted(df["year"].unique()):
        year_df = df[df["year"] == year]
        coef_df, pseudo_r2 = fit_logistic_regression(year_df, features)
        if coef_df.empty:
            continue
        coef_df["year"] = int(year)
        coef_df["pseudo_r2"] = pseudo_r2
        coef_df["source_domain"] = year_df["source_domain"].mode().iloc[0]
        all_results.append(coef_df)
    return pd.concat(all_results, ignore_index=True) if all_results else pd.DataFrame()


def stratified_regression_by_disagreement(df: pd.DataFrame) -> pd.DataFrame:
    features = [f"{f}_std" for f in QUALITY_PROXIES + CORE_LANGUAGE_FEATURES]
    all_results = []
    for level in ["low", "medium", "high"]:
        level_df = df[df["disagreement_level"] == level]
        coef_df, pseudo_r2 = fit_logistic_regression(level_df, features)
        if coef_df.empty:
            continue
        coef_df["disagreement_level"] = level
        coef_df["pseudo_r2"] = pseudo_r2
        all_results.append(coef_df)
    return pd.concat(all_results, ignore_index=True) if all_results else pd.DataFrame()


def stratified_regression_by_source(df: pd.DataFrame) -> pd.DataFrame:
    features = [f"{f}_std" for f in QUALITY_PROXIES + CORE_LANGUAGE_FEATURES]
    all_results = []
    for source in sorted(df["source_domain"].unique()):
        source_df = df[df["source_domain"] == source]
        coef_df, pseudo_r2 = fit_logistic_regression(source_df, features)
        if coef_df.empty:
            continue
        coef_df["source_domain"] = source
        coef_df["pseudo_r2"] = pseudo_r2
        all_results.append(coef_df)
    return pd.concat(all_results, ignore_index=True) if all_results else pd.DataFrame()


def plot_coefficient_comparison_by_year(results_df: pd.DataFrame) -> None:
    for feat in CORE_LANGUAGE_FEATURES:
        feat_name = f"{feat}_std"
        feat_df = results_df[results_df["feature"] == feat_name].copy()
        if feat_df.empty:
            continue

        fig, ax = plt.subplots(figsize=(8, 5))
        years = feat_df["year"].values
        coefs = feat_df["coef"].values
        ci_low = feat_df["ci_low"].values
        ci_high = feat_df["ci_high"].values

        y_pos = np.arange(len(years))
        ax.errorbar(
            coefs,
            y_pos,
            xerr=[coefs - ci_low, ci_high - coefs],
            fmt="o",
            capsize=4,
            color="#1f77b4",
        )
        ax.axvline(x=0, color="gray", linestyle="--", alpha=0.6)
        ax.set_yticks(y_pos)
        ax.set_yticklabels([str(int(y)) for y in years])
        ax.set_xlabel("Coefficient (95% CI)")
        ax.set_ylabel("Year")
        ax.set_title(f"{feat}: Coefficient Stability Across Years")
        fig.tight_layout()
        fig.savefig(OUT_DIR / f"{feat}_coef_by_year.png", dpi=200)
        plt.close(fig)


def fit_interaction_model_year(df: pd.DataFrame) -> pd.DataFrame:
    work = df.copy()
    year_dummies = pd.get_dummies(work["year"].astype(str), prefix="year", drop_first=True, dtype=float)
    period_dummies = pd.get_dummies(work["period_bucket"].astype(str), prefix="period", drop_first=True, dtype=float)
    source_dummies = pd.get_dummies(work["source_domain"].astype(str), prefix="source", drop_first=True, dtype=float)

    features = [f"{f}_std" for f in QUALITY_PROXIES + CORE_LANGUAGE_FEATURES]
    x = work[features].copy()
    x = pd.concat([x, year_dummies, period_dummies, source_dummies], axis=1)

    for feat in CORE_LANGUAGE_FEATURES:
        feat_std = f"{feat}_std"
        for year_col in year_dummies.columns:
            x[f"{feat_std}_x_{year_col}"] = x[feat_std] * year_dummies[year_col]

    x = sm.add_constant(x, has_constant="add")
    y = work["decision"].astype(int)

    valid = x.notna().all(axis=1) & y.notna()
    x = x[valid]
    y = y[valid]

    try:
        model = sm.GLM(y, x, family=sm.families.Binomial()).fit()
    except Exception as exc:
        print(f"[WARN] interaction_model_year failed: {exc}")
        return pd.DataFrame()

    coef_df = pd.DataFrame(
        {
            "feature": model.params.index,
            "coef": model.params.values,
            "std_err": model.bse.values,
            "z": model.tvalues.values,
            "pvalue": model.pvalues.values,
            "ci_low": model.conf_int()[0].values,
            "ci_high": model.conf_int()[1].values,
        }
    )
    coef_df["odds_ratio"] = np.exp(coef_df["coef"])
    coef_df["or_ci_low"] = np.exp(coef_df["ci_low"])
    coef_df["or_ci_high"] = np.exp(coef_df["ci_high"])
    coef_df["n"] = len(y)
    coef_df["pseudo_r2"] = 1 - (model.llf / model.llnull) if model.llnull != 0 else np.nan
    return coef_df


def fit_interaction_model_disagreement(df: pd.DataFrame) -> pd.DataFrame:
    work = df.copy()
    disagree_dummies = pd.get_dummies(work["disagreement_level"], prefix="disagree", drop_first=True, dtype=float)
    period_dummies = pd.get_dummies(work["period_bucket"].astype(str), prefix="period", drop_first=True, dtype=float)
    source_dummies = pd.get_dummies(work["source_domain"].astype(str), prefix="source", drop_first=True, dtype=float)

    features = [f"{f}_std" for f in ["mean_score", "mean_confidence", "num_reviews"] + CORE_LANGUAGE_FEATURES]
    x = work[features].copy()
    x = pd.concat([x, disagree_dummies, period_dummies, source_dummies], axis=1)

    for feat in CORE_LANGUAGE_FEATURES:
        feat_std = f"{feat}_std"
        for disagree_col in disagree_dummies.columns:
            x[f"{feat_std}_x_{disagree_col}"] = x[feat_std] * disagree_dummies[disagree_col]

    x = sm.add_constant(x, has_constant="add")
    y = work["decision"].astype(int)

    valid = x.notna().all(axis=1) & y.notna()
    x = x[valid]
    y = y[valid]

    try:
        model = sm.GLM(y, x, family=sm.families.Binomial()).fit()
    except Exception as exc:
        print(f"[WARN] interaction_model_disagreement failed: {exc}")
        return pd.DataFrame()

    coef_df = pd.DataFrame(
        {
            "feature": model.params.index,
            "coef": model.params.values,
            "std_err": model.bse.values,
            "z": model.tvalues.values,
            "pvalue": model.pvalues.values,
            "ci_low": model.conf_int()[0].values,
            "ci_high": model.conf_int()[1].values,
        }
    )
    coef_df["odds_ratio"] = np.exp(coef_df["coef"])
    coef_df["or_ci_low"] = np.exp(coef_df["ci_low"])
    coef_df["or_ci_high"] = np.exp(coef_df["ci_high"])
    coef_df["n"] = len(y)
    coef_df["pseudo_r2"] = 1 - (model.llf / model.llnull) if model.llnull != 0 else np.nan
    return coef_df


def fit_interaction_model_source(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    work = df.copy()
    source_peerread = (work["source_domain"] == "peerread").astype(float)

    features = [f"{f}_std" for f in QUALITY_PROXIES + CORE_LANGUAGE_FEATURES]
    x_base = work[features].copy()
    x_base["source_peerread"] = source_peerread

    year_dummies = pd.get_dummies(work["year"].astype(str), prefix="year", drop_first=True, dtype=float)
    period_dummies = pd.get_dummies(work["period_bucket"].astype(str), prefix="period", drop_first=True, dtype=float)
    x_base = pd.concat([x_base, year_dummies, period_dummies], axis=1)
    x_base = sm.add_constant(x_base, has_constant="add")

    x_full = x_base.copy()
    for feat in CORE_LANGUAGE_FEATURES:
        feat_std = f"{feat}_std"
        x_full[f"{feat_std}_x_source_peerread"] = x_full[feat_std] * source_peerread

    y = work["decision"].astype(float)
    valid_base = x_base.notna().all(axis=1) & y.notna()
    valid_full = x_full.notna().all(axis=1) & y.notna()
    valid = valid_base & valid_full
    x_base = x_base[valid]
    x_full = x_full[valid]
    y = y[valid]

    try:
        model_base = sm.GLM(y, x_base, family=sm.families.Binomial()).fit()
        model_full = sm.GLM(y, x_full, family=sm.families.Binomial()).fit()
    except Exception as exc:
        print(f"[WARN] interaction_model_source failed: {exc}")
        return pd.DataFrame(), pd.DataFrame()

    lr_stat = -2 * (model_base.llf - model_full.llf)
    df_diff = float(model_full.df_model - model_base.df_model)
    pval = stats.chi2.sf(lr_stat, df_diff) if df_diff > 0 else np.nan

    lrt_df = pd.DataFrame(
        [
            {
                "model_base": "quality+language+source+year_fe+period_fe",
                "model_full": "base+language_x_source",
                "n": int(len(y)),
                "base_pseudo_r2": 1 - (model_base.llf / model_base.llnull) if model_base.llnull != 0 else np.nan,
                "full_pseudo_r2": 1 - (model_full.llf / model_full.llnull) if model_full.llnull != 0 else np.nan,
                "delta_pseudo_r2": (1 - (model_full.llf / model_full.llnull))
                - (1 - (model_base.llf / model_base.llnull))
                if model_full.llnull != 0 and model_base.llnull != 0
                else np.nan,
                "lrt_stat": float(lr_stat),
                "lrt_df_diff": float(df_diff),
                "lrt_pvalue": float(pval) if not np.isnan(pval) else np.nan,
            }
        ]
    )

    coef_df = pd.DataFrame(
        {
            "feature": model_full.params.index,
            "coef": model_full.params.values,
            "std_err": model_full.bse.values,
            "z": model_full.tvalues.values,
            "pvalue": model_full.pvalues.values,
            "ci_low": model_full.conf_int()[0].values,
            "ci_high": model_full.conf_int()[1].values,
        }
    )
    coef_df["odds_ratio"] = np.exp(coef_df["coef"])
    coef_df["or_ci_low"] = np.exp(coef_df["ci_low"])
    coef_df["or_ci_high"] = np.exp(coef_df["ci_high"])
    coef_df["n"] = len(y)
    return coef_df, lrt_df


def evaluate_model_predictions(y_true: np.ndarray, y_prob: np.ndarray) -> Dict[str, float]:
    return {
        "auc": float(roc_auc_score(y_true, y_prob)) if len(np.unique(y_true)) > 1 else np.nan,
        "log_loss": float(log_loss(y_true, y_prob, labels=[0, 1])),
        "brier_score": float(brier_score_loss(y_true, y_prob)),
    }


def cross_year_validation(df: pd.DataFrame) -> pd.DataFrame:
    results = []
    baseline_features = [f"{f}_std" for f in QUALITY_PROXIES]
    full_features = [f"{f}_std" for f in QUALITY_PROXIES + CORE_LANGUAGE_FEATURES]

    for test_year in sorted(df["year"].unique()):
        train_df = df[df["year"] != test_year]
        test_df = df[df["year"] == test_year]
        if len(test_df) < 20 or len(train_df) < 50:
            continue

        for model_name, features in [("baseline", baseline_features), ("with_language", full_features)]:
            train_sub = train_df[["decision"] + features].dropna()
            test_sub = test_df[["decision"] + features].dropna()
            if len(train_sub) < 30 or len(test_sub) < 10:
                continue

            x_train = train_sub[features].copy()
            y_train = train_sub["decision"].astype(int)
            x_test = test_sub[features].copy()
            y_test = test_sub["decision"].astype(int)

            clf = LogisticRegression(max_iter=2000, random_state=42)
            clf.fit(x_train, y_train)
            y_prob = clf.predict_proba(x_test)[:, 1]

            metrics = evaluate_model_predictions(y_test.values, y_prob)
            metrics["test_year"] = int(test_year)
            metrics["model"] = model_name
            metrics["n_train"] = int(len(train_sub))
            metrics["n_test"] = int(len(test_sub))
            results.append(metrics)

    return pd.DataFrame(results)


def compute_language_improvement(cv_results: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for year in sorted(cv_results["test_year"].unique()):
        year_df = cv_results[cv_results["test_year"] == year]
        baseline = year_df[year_df["model"] == "baseline"]
        with_lang = year_df[year_df["model"] == "with_language"]
        if baseline.empty or with_lang.empty:
            continue
        b = baseline.iloc[0]
        l = with_lang.iloc[0]
        rows.append(
            {
                "test_year": int(year),
                "delta_auc": float(l["auc"] - b["auc"]),
                "delta_log_loss": float(b["log_loss"] - l["log_loss"]),
                "delta_brier": float(b["brier_score"] - l["brier_score"]),
                "baseline_auc": float(b["auc"]),
                "with_language_auc": float(l["auc"]),
            }
        )
    return pd.DataFrame(rows)


def cross_domain_iclr_to_peerread(df: pd.DataFrame) -> pd.DataFrame:
    train = df[df["source_domain"] == "iclr"].copy()
    test = df[df["source_domain"] == "peerread"].copy()
    if train.empty or test.empty:
        return pd.DataFrame()

    train["year_centered"] = train["year"] - 2017
    test["year_centered"] = test["year"] - 2017
    configs = {
        "baseline_with_time_control": QUALITY_PROXIES + ["year_centered"],
        "with_language_with_time_control": QUALITY_PROXIES + CORE_LANGUAGE_FEATURES + ["year_centered"],
    }

    rows = []
    for model_name, raw_features in configs.items():
        features = [f if f == "year_centered" else f"{f}_std" for f in raw_features]
        train_sub = train[["decision"] + features].dropna()
        test_sub = test[["decision"] + features].dropna()
        if train_sub.empty or test_sub.empty:
            continue

        x_train = train_sub[features].copy()
        y_train = train_sub["decision"].astype(int)
        x_test = test_sub[features].copy()
        y_test = test_sub["decision"].astype(int)

        mean = x_train.mean()
        std = x_train.std(ddof=0).replace(0, 1)
        x_train = (x_train - mean) / std
        x_test = (x_test - mean) / std

        clf = LogisticRegression(max_iter=2000, random_state=42)
        clf.fit(x_train, y_train)
        y_prob = clf.predict_proba(x_test)[:, 1]

        metrics = evaluate_model_predictions(y_test.values, y_prob)
        metrics["model_name"] = model_name
        metrics["n_train"] = int(len(train_sub))
        metrics["n_test"] = int(len(test_sub))
        rows.append(metrics)
    return pd.DataFrame(rows)


def compute_meta_analysis(stratified_results: pd.DataFrame) -> pd.DataFrame:
    results = []
    for feat in CORE_LANGUAGE_FEATURES:
        feat_name = f"{feat}_std"
        feat_df = stratified_results[stratified_results["feature"] == feat_name].copy()
        feat_df = feat_df.dropna(subset=["coef", "std_err"])
        if len(feat_df) < 2:
            continue

        effects = feat_df["coef"].values
        se = feat_df["std_err"].values
        se = np.where(se <= 0, 0.001, se)

        weights = 1.0 / (se**2)
        pooled_fe = np.sum(weights * effects) / np.sum(weights)
        pooled_se_fe = np.sqrt(1.0 / np.sum(weights))

        q = np.sum(weights * (effects - pooled_fe) ** 2)
        df_q = len(effects) - 1
        q_pvalue = 1 - stats.chi2.cdf(q, df_q) if df_q > 0 else np.nan
        i2 = max(0, (q - df_q) / q) * 100 if q > 0 else 0

        tau2 = max(0, (q - df_q) / (np.sum(weights) - np.sum(weights**2) / np.sum(weights)))
        weights_re = 1.0 / (se**2 + tau2)
        pooled_re = np.sum(weights_re * effects) / np.sum(weights_re)
        pooled_se_re = np.sqrt(1.0 / np.sum(weights_re))

        results.append(
            {
                "feature": feat,
                "n_years": len(effects),
                "pooled_effect_fe": pooled_fe,
                "pooled_se_fe": pooled_se_fe,
                "pooled_effect_re": pooled_re,
                "pooled_se_re": pooled_se_re,
                "Q_statistic": q,
                "Q_df": df_q,
                "Q_pvalue": q_pvalue,
                "I2_percent": i2,
                "tau2": tau2,
                "min_effect": effects.min(),
                "max_effect": effects.max(),
                "effect_range": effects.max() - effects.min(),
            }
        )
    return pd.DataFrame(results)


def interpret_stability(meta_results: pd.DataFrame) -> pd.DataFrame:
    out = meta_results.copy()

    def map_i2(v):
        if v < 25:
            return "stable (low heterogeneity)"
        if v < 75:
            return "partially stable (moderate heterogeneity)"
        return "unstable (high heterogeneity)"

    out["stability_interpretation"] = out["I2_percent"].apply(map_i2)
    return out


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    print("[INFO] Step 1: Loading and preparing combined dataset...")
    df = load_combined_rq1_data()
    df = prepare_analysis_dataset(df)
    print(
        f"[INFO] Loaded {len(df)} papers from {df['year'].nunique()} years "
        f"(ICLR={int((df['source_domain']=='iclr').sum())}, PeerRead={int((df['source_domain']=='peerread').sum())})"
    )

    print("[INFO] Step 2: Computing descriptive statistics and plots...")
    desc_year = compute_descriptive_by_year(df)
    desc_year.to_csv(OUT_DIR / "descriptive_by_year.csv", index=False)
    desc_disagree = compute_descriptive_by_disagreement(df)
    desc_disagree.to_csv(OUT_DIR / "descriptive_by_disagreement.csv", index=False)
    desc_source = compute_descriptive_by_source(df)
    desc_source.to_csv(OUT_DIR / "descriptive_by_source.csv", index=False)

    plot_acceptance_rate_by_year(df)
    plot_language_features_by_year(df)
    plot_language_features_by_disagreement(df)

    print("[INFO] Step 3: Fitting stratified logistic regressions...")
    strat_year = stratified_regression_by_year(df)
    strat_year.to_csv(OUT_DIR / "stratified_logit_by_year.csv", index=False)
    strat_disagree = stratified_regression_by_disagreement(df)
    strat_disagree.to_csv(OUT_DIR / "stratified_logit_by_disagreement.csv", index=False)
    strat_source = stratified_regression_by_source(df)
    strat_source.to_csv(OUT_DIR / "stratified_logit_by_source.csv", index=False)
    if not strat_year.empty:
        plot_coefficient_comparison_by_year(strat_year)

    print("[INFO] Step 4: Fitting pooled interaction models...")
    interaction_year = fit_interaction_model_year(df)
    interaction_year.to_csv(OUT_DIR / "interaction_model_year.csv", index=False)
    interaction_disagree = fit_interaction_model_disagreement(df)
    interaction_disagree.to_csv(OUT_DIR / "interaction_model_disagreement.csv", index=False)
    interaction_source, interaction_source_lrt = fit_interaction_model_source(df)
    interaction_source.to_csv(OUT_DIR / "interaction_model_source.csv", index=False)
    interaction_source_lrt.to_csv(OUT_DIR / "interaction_model_source_lrt.csv", index=False)

    print("[INFO] Step 5: Running cross-year validation...")
    cv_results = cross_year_validation(df)
    cv_results.to_csv(OUT_DIR / "cross_year_validation.csv", index=False)
    if not cv_results.empty:
        improvement = compute_language_improvement(cv_results)
        improvement.to_csv(OUT_DIR / "language_improvement_by_year.csv", index=False)

    cross_domain = cross_domain_iclr_to_peerread(df)
    cross_domain.to_csv(OUT_DIR / "cross_domain_iclr_to_peerread.csv", index=False)

    print("[INFO] Step 6: Performing meta-analysis...")
    if not strat_year.empty:
        meta_results = compute_meta_analysis(strat_year)
        meta_results = interpret_stability(meta_results)
        meta_results.to_csv(OUT_DIR / "meta_analysis_results.csv", index=False)

    summary = {
        "combined_n": int(len(df)),
        "iclr_n": int((df["source_domain"] == "iclr").sum()),
        "peerread_n": int((df["source_domain"] == "peerread").sum()),
        "peerread_year_nunique": int(df.loc[df["source_domain"] == "peerread", "year"].nunique()),
        "combined_year_min": int(df["year"].min()),
        "combined_year_max": int(df["year"].max()),
    }
    pd.DataFrame([summary]).to_csv(OUT_DIR / "rq3_eval_summary.csv", index=False)

    if summary["peerread_year_nunique"] <= 1:
        print(
            "[WARN] PeerRead usable rows are concentrated in one year; "
            "temporal controls are included but within-PeerRead temporal heterogeneity is limited."
        )

    print(f"[DONE] Eval-RQ3 complete. Outputs saved to: {OUT_DIR.resolve()}")


if __name__ == "__main__":
    main()
