from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import seaborn as sns

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from rq1_iclr_analysis import (  # noqa: E402
    CORE_FEATURES,
    build_lexicon_resources,
    descriptive_and_tests,
    fit_multivariable_logit,
    fit_univariate_logit,
    get_sentiment_analyzer,
)

from peerread_eval_common import build_peerread_paper_level  # noqa: E402


OUT_DIR = PROJECT_ROOT / "eval" / "outputs" / "rq1"


def save_boxplots(df: pd.DataFrame, out_dir: Path) -> None:
    sns.set_theme(style="whitegrid")
    for feat in CORE_FEATURES:
        fig, ax = plt.subplots(figsize=(7, 5))
        sns.boxplot(
            data=df,
            x="decision_label",
            y=feat,
            hue="decision_label",
            palette=["#d95f02", "#1b9e77"],
            legend=False,
            ax=ax,
        )
        ax.set_title(f"{feat} by Final Decision")
        ax.set_xlabel("Final Decision")
        ax.set_ylabel(feat)
        fig.tight_layout()
        fig.savefig(out_dir / f"{feat}_boxplot.png", dpi=200)
        plt.close(fig)


def save_lexicon_summary(lexicons, out_dir: Path) -> None:
    summary = pd.DataFrame(
        [
            {"lexicon": "sentiment_pos_words", "size": len(lexicons.sentiment_pos_words)},
            {"lexicon": "sentiment_neg_words", "size": len(lexicons.sentiment_neg_words)},
            {"lexicon": "afinn_scores", "size": len(lexicons.afinn_scores)},
            {"lexicon": "politeness_pos_words", "size": len(lexicons.politeness_pos_words)},
            {"lexicon": "politeness_neg_words", "size": len(lexicons.politeness_neg_words)},
            {"lexicon": "politeness_pos_phrases", "size": len(lexicons.politeness_pos_phrases)},
            {"lexicon": "politeness_neg_phrases", "size": len(lexicons.politeness_neg_phrases)},
            {"lexicon": "toxic_words", "size": len(lexicons.toxic_words)},
            {"lexicon": "toxic_phrases", "size": len(lexicons.toxic_phrases)},
            {"lexicon": "constructive_words", "size": len(lexicons.constructive_words)},
            {"lexicon": "constructive_phrases", "size": len(lexicons.constructive_phrases)},
            {"lexicon": "hedge_words", "size": len(lexicons.hedge_words)},
            {"lexicon": "hedge_phrases", "size": len(lexicons.hedge_phrases)},
        ]
    )
    summary.to_csv(out_dir / "lexicon_summary.csv", index=False)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    print("[INFO] Step 1/4: Building lexicon resources...")
    sia = get_sentiment_analyzer()
    lexicons = build_lexicon_resources()
    save_lexicon_summary(lexicons, OUT_DIR)

    print("[INFO] Step 2/4: Building PeerRead paper-level dataset...")
    paper_level, ingest_summary = build_peerread_paper_level(sia, lexicons)
    ingest_summary.to_csv(OUT_DIR / "peerread_ingest_summary.csv", index=False)

    if paper_level.empty:
        print("[ERROR] No usable PeerRead rows with both decision labels and review text.")
        return

    paper_level = paper_level[paper_level["decision"].notna()].copy()
    paper_level["decision"] = paper_level["decision"].astype(int)
    paper_level["decision_label"] = paper_level["decision"].map({1: "accept", 0: "reject"})
    paper_level = paper_level[paper_level["num_reviews"].fillna(0) > 0].copy()

    output_main = OUT_DIR / "paper_level_rq1_dataset.csv"
    paper_level.to_csv(output_main, index=False)

    print("[INFO] Step 3/4: Running RQ1 descriptive and regression analyses...")
    desc = (
        paper_level.groupby("decision_label")[CORE_FEATURES + ["num_reviews", "mean_review_length"]]
        .agg(["mean", "median", "std", "count"])
        .reset_index()
    )
    desc.columns = [
        "decision_label" if c == "decision_label" else f"{c[0]}_{c[1]}".strip("_")
        for c in desc.columns.to_flat_index()
    ]
    desc.to_csv(OUT_DIR / "descriptive_stats.csv", index=False)

    tests_df = descriptive_and_tests(paper_level)
    tests_df.to_csv(OUT_DIR / "univariate_group_tests.csv", index=False)

    uni_logit = fit_univariate_logit(paper_level)
    uni_logit.to_csv(OUT_DIR / "univariate_logit.csv", index=False)

    multi_logit = fit_multivariable_logit(paper_level)
    multi_logit.to_csv(OUT_DIR / "multivariable_logit.csv", index=False)

    print("[INFO] Step 4/4: Saving RQ1-style plots...")
    save_boxplots(paper_level, OUT_DIR)

    print(f"[DONE] Main dataset: {output_main}")
    print(f"[DONE] Outputs saved in: {OUT_DIR.resolve()}")


if __name__ == "__main__":
    main()
