from __future__ import annotations

import subprocess
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def run(script_name: str) -> None:
    script = PROJECT_ROOT / "eval" / script_name
    print(f"[INFO] Running {script.name} ...")
    subprocess.run([sys.executable, str(script)], check=True)


def main() -> None:
    run("rq1_eval.py")
    run("rq2_eval.py")
    run("rq3_eval.py")
    print("[DONE] All eval stages completed.")


if __name__ == "__main__":
    main()
